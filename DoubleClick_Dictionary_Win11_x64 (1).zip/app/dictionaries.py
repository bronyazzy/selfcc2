import codecs
import csv
import hashlib
import os
import re
import sqlite3
import unicodedata
import uuid
import zlib
from contextlib import closing
from dataclasses import dataclass
from itertools import chain
from pathlib import Path, PurePosixPath
from urllib.parse import unquote

from word_forms import forms


SUFFIXES = {".mdx", ".tsv", ".csv"}
IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".svg", ".ico"}
SOUND_SUFFIXES = {".mp3", ".wav"}
MAX_ASSET_BYTES = 16 * 1024 * 1024
CHARACTERS = str.maketrans({"’": "'", "‘": "'", "‐": "-", "‑": "-", "\u200b": None, "\u00ad": None, "\ufeff": None})


def clean_term(text):
    text = unicodedata.normalize("NFKC", text).translate(CHARACTERS)
    return " ".join(text.split()).strip(" \"'“”()[]{}<>.,!?;:，。！？；：、（）【】《》")


def selected_word(text):
    term = clean_term(text)
    if len(term) > 64 or not any(char.isalpha() for char in term):
        return ""
    if any(not (char.isalnum() or char in "'-/._" or unicodedata.category(char).startswith("M")) for char in term):
        return ""
    return term


def asset_key(path):
    path = path.replace("\\", "/").lstrip("/")
    parts = [part for part in path.split("/") if part not in ("", ".")]
    if any(part == ".." or ":" in part or "\x00" in part for part in parts):
        return ""
    return "/".join(parts).casefold()


@dataclass(frozen=True)
class Dictionary:
    file: Path
    name: str
    source: str
    entries: int
    media: int


@dataclass(frozen=True)
class Entry:
    dictionary: Dictionary
    headword: str
    definition: str
    is_html: bool


@dataclass(frozen=True)
class Import:
    temporary: Path
    destination: Path
    warnings: list[str]


def m_dict(source, resource=False):
    from mdict_utils.base import lzo, readmdict

    # The bundled pure-Python LZO decoder accepts raw data, while the reader
    # normally passes a five-byte python-lzo header.
    if readmdict.lzo is None:
        class LzoDecoder:
            @staticmethod
            def decompress(block):
                return lzo.decompress(block[5:], initSize=int.from_bytes(block[1:5], "big"), blockSize=1308672)

        readmdict.lzo = LzoDecoder

    class MDictReader(readmdict.MDD if resource else readmdict.MDX):
        def _read_keys_brutal(self):
            raise ValueError("此字典需要注册信息。请导入不需要注册的版本。")

    with source.open("rb") as stream:
        header_length = int.from_bytes(stream.read(4), "big")
    if not 4 <= header_length <= min(1024 * 1024, source.stat().st_size - 8):
        raise ValueError("文件头无效，无法读取 MDict 字典。")
    if resource:
        return MDictReader(str(source))
    return MDictReader(str(source), substyle=True)


def companion_files(source):
    name = re.escape(source.stem)
    pattern = re.compile(rf"{name}(?:\.\d+)?\.mdd", re.IGNORECASE)
    return sorted(
        (file for file in source.parent.iterdir() if file.is_file() and pattern.fullmatch(file.name)),
        key=lambda file: (file.name.casefold() != f"{source.stem.casefold()}.mdd", file.name.casefold()),
    )


def table_items(source):
    with source.open("rb") as stream:
        preview = stream.read(65536)
    encoding = "utf-8-sig"
    if preview.startswith((codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE)):
        encoding = "utf-16"
    else:
        try:
            codecs.getincrementaldecoder(encoding)().decode(preview, final=False)
        except UnicodeDecodeError:
            encoding = "gb18030"

    with source.open(encoding=encoding, newline="") as stream:
        for index, row in enumerate(csv.reader(stream, delimiter="\t" if source.suffix.lower() == ".tsv" else ",")):
            if len(row) < 2:
                continue
            term, definition = row[:2]
            if index == 0 and term.strip().casefold() in {"word", "term", "headword", "单词", "詞條", "词条"}:
                if definition.strip().casefold() in {"definition", "translation", "meaning", "释义", "釋義", "翻译", "翻譯"}:
                    continue
            yield term, definition


def open_readonly(file):
    return closing(sqlite3.connect(file.as_uri() + "?mode=ro", uri=True))


class DictionaryStore:
    def __init__(self, folder):
        self.folder = folder.resolve()
        self.folder.mkdir(parents=True, exist_ok=True)

    def list(self):
        dictionaries = []
        for file in self.folder.glob("*.sqlite3"):
            try:
                with open_readonly(file) as db:
                    row = db.execute("SELECT name, source, entries, media FROM metadata").fetchone()
                if row:
                    dictionaries.append(Dictionary(file, *row))
            except sqlite3.Error:
                continue
        return sorted(dictionaries, key=lambda item: (item.name.casefold(), item.source.casefold()))

    def prepare(self, source, progress):
        source = source.resolve(strict=True)
        suffix = source.suffix.lower()
        if suffix not in SUFFIXES:
            raise ValueError("请选择 MDX、CSV 或 TSV 字典。")
        digest = hashlib.sha256(os.path.normcase(str(source)).encode("utf-8")).hexdigest()[:24]
        temporary = self.folder / f"{uuid.uuid4().hex}.tmp"
        destination = self.folder / f"{digest}.sqlite3"
        warnings = []
        try:
            with closing(sqlite3.connect(temporary)) as db, db:
                db.executescript("""
                    CREATE TABLE metadata(name TEXT, source TEXT, entries INTEGER, media INTEGER);
                    CREATE TABLE entry(key TEXT, term TEXT, body BLOB, html INTEGER);
                    CREATE TABLE asset(key TEXT PRIMARY KEY, data BLOB) WITHOUT ROWID;
                """)
                name = source.stem
                is_mdx = suffix == ".mdx"
                progress(f"正在读取 {source.name}")
                if is_mdx:
                    reader = m_dict(source)
                    items = ((key.decode("utf-8"), data.decode("utf-8")) for key, data in reader.items())
                    total = f" / {len(reader):,}"
                else:
                    items = table_items(source)
                    total = ""

                def rows():
                    for index, (word, definition) in enumerate(items, 1):
                        if index % 2048 == 0:
                            progress(f"正在导入 {name} · {index:,}{total} 条")
                        term = clean_term(word)
                        if term and definition.strip():
                            yield term.casefold(), term, zlib.compress(definition.encode("utf-8"), 3), is_mdx

                count = db.executemany("INSERT INTO entry VALUES (?, ?, ?, ?)", rows()).rowcount
                if not count:
                    raise ValueError("字典里没有可导入的词条。")
                db.execute("CREATE INDEX entry_lookup ON entry(key)")
                for companion in companion_files(source) if is_mdx else ():
                    progress(f"正在导入配套资源 {companion.name}")
                    db.execute("SAVEPOINT media_file")
                    try:
                        resources = m_dict(companion, resource=True)
                        for index, (filename, data) in enumerate(resources.items(), 1):
                            if index % 2048 == 0:
                                progress(f"正在导入 {companion.name} · {index:,} / {len(resources):,}")
                            key = asset_key(filename.decode("utf-8"))
                            if PurePosixPath(key).suffix in IMAGE_SUFFIXES | SOUND_SUFFIXES and 0 < len(data) <= MAX_ASSET_BYTES:
                                db.execute("INSERT OR IGNORE INTO asset VALUES (?, ?)", (key, data))
                    except sqlite3.Error:
                        raise
                    except Exception:
                        db.execute("ROLLBACK TO media_file")
                        warnings.append(f"{companion.name} 的资源无法读取。")
                    finally:
                        db.execute("RELEASE media_file")
                media = db.execute("SELECT count(*) FROM asset").fetchone()[0]
                db.execute("INSERT INTO metadata VALUES (?, ?, ?, ?)", (name, str(source), count, media))
        except BaseException:
            temporary.unlink(missing_ok=True)
            raise
        return Import(temporary, destination, warnings)

    def commit(self, prepared):
        os.replace(prepared.temporary, prepared.destination)

    @staticmethod
    def _entries(db, dictionary, key, seen):
        if key in seen or len(seen) >= 32:
            return []
        seen.add(key)
        entries = []
        cursor = db.execute("SELECT term, body, html FROM entry WHERE key=? ORDER BY rowid LIMIT 30", (key,))
        for word, body, is_html in cursor:
            definition = zlib.decompress(body).decode("utf-8").strip()
            if is_html and definition.startswith("@@@LINK="):
                target = clean_term(definition[len("@@@LINK="):].strip("\x00\r\n ")).casefold()
                entries.extend(DictionaryStore._entries(db, dictionary, target, seen))
            else:
                entries.append(Entry(dictionary, word, definition, bool(is_html)))
        return entries

    def lookup(self, term, dictionaries):
        key = clean_term(term).casefold()
        if not key:
            return [], ""
        for candidate in chain((key,), forms(key)):
            result = []
            for dictionary in dictionaries:
                with open_readonly(dictionary.file) as db:
                    result.extend(self._entries(db, dictionary, candidate, set()))
            if result:
                return list(dict.fromkeys(result)), candidate if candidate != key else ""
        return [], ""

    @staticmethod
    def media(dictionaries, identifier, url_path):
        dictionary = next((item for item in dictionaries if item.file.stem == identifier), None)
        key = asset_key(unquote(url_path))
        if not dictionary or not key or not dictionary.media:
            return None
        with open_readonly(dictionary.file) as db:
            row = db.execute("SELECT data FROM asset WHERE key=?", (key,)).fetchone()
        return row[0] if row else None
