import re
from functools import cache
from pathlib import Path


WORDNET = Path(__file__).with_name("wordnet")
FINAL_SINGLE_VOWEL_AND_CONSONANT = re.compile(r"(?<![aeiou])[aeiou][bcdfghjklmnpqrstvz]$")
SUPPLEMENTAL = {
    "being": ("be",),
    "does": ("do", "doe"),
    "ranging": ("range",),
}


@cache
def wordnet_exceptions():
    exceptions = {}
    for name in ("verb.exc", "noun.exc"):
        with (WORDNET / name).open(encoding="ascii") as source:
            for line in source:
                inflected, *roots = line.split()
                options = exceptions.setdefault(inflected, [])
                for root in roots:
                    if root != inflected and root.isascii() and root.isalpha() and root not in options:
                        options.append(root)
    return exceptions


def regular_forms(word):
    if word.endswith(("ies", "ied")):
        stem = word[:-3]
        if len(stem) == 1:
            yield stem + "ie"
        elif stem:
            yield stem + "y"
            yield stem + "ie"

    if word.endswith("s") and not word.endswith("ss") and len(word) >= 3:
        if word.endswith("es") and word[:-2].endswith(("ch", "sh", "ss", "x", "zz")):
            yield word[:-2]
        yield word[:-1]
        if word.endswith("es") and len(word) >= 4:
            yield word[:-2]

    if word.endswith("ing"):
        stem = word[:-3]
    elif word.endswith("ed"):
        stem = word[:-2]
    else:
        return
    if len(stem) < 2:
        return

    # An undoubled consonant in hoping/dining usually points to hope/dine.
    # Keep existing doubled stems such as add and fill before trying to shorten them.
    likely_silent_e = stem.endswith("u") or FINAL_SINGLE_VOWEL_AND_CONSONANT.search(stem)
    if likely_silent_e:
        yield stem + "e"
    yield stem
    if len(stem) >= 3 and (stem.endswith("ck") or (stem[-2] == stem[-1] and stem[-1] not in "aeiou")):
        yield stem[:-1]
    if not likely_silent_e:
        yield stem + "e"


def forms(term):
    """Offer likely English headwords for a case-folded selected term."""
    prefix, separator, word = term.rpartition("-")
    if not word.isascii() or not word.isalpha():
        return
    candidates = (*SUPPLEMENTAL.get(word, ()), *wordnet_exceptions().get(word, ()), *regular_forms(word))
    for base in dict.fromkeys(candidates):
        if base != word:
            yield prefix + separator + base
