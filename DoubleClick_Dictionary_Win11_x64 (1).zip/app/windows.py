import ctypes as c
import logging
import os
import queue
import sys
import threading
import time
from ctypes import wintypes as w
from dataclasses import dataclass
from pathlib import PureWindowsPath

from dictionaries import selected_word


user = c.WinDLL("user32", use_last_error=True)
kernel = c.WinDLL("kernel32", use_last_error=True)
winmm = c.WinDLL("winmm")
ULONG_PTR = c.c_size_t
LRESULT = c.c_ssize_t
HOOKPROC = c.WINFUNCTYPE(LRESULT, c.c_int, w.WPARAM, w.LPARAM)


class MouseEvent(c.Structure):
    _fields_ = [("point", w.POINT), ("data", w.DWORD), ("flags", w.DWORD), ("time", w.DWORD), ("extra", ULONG_PTR)]


class KeyInput(c.Structure):
    _fields_ = [("key", w.WORD), ("scan", w.WORD), ("flags", w.DWORD), ("time", w.DWORD), ("extra", ULONG_PTR)]


class MouseInput(c.Structure):
    _fields_ = [("dx", w.LONG), ("dy", w.LONG), ("data", w.DWORD), ("flags", w.DWORD), ("time", w.DWORD), ("extra", ULONG_PTR)]


class InputData(c.Union):
    _fields_ = [("key", KeyInput), ("mouse", MouseInput)]


class Input(c.Structure):
    _fields_ = [("type", w.DWORD), ("data", InputData)]


def bind(dll, name, result, *arguments):
    function = getattr(dll, name)
    function.restype = result
    function.argtypes = arguments
    return function


set_mouse_hook = bind(user, "SetWindowsHookExW", w.HHOOK, c.c_int, HOOKPROC, w.HINSTANCE, w.DWORD)
remove_hook = bind(user, "UnhookWindowsHookEx", w.BOOL, w.HHOOK)
next_hook = bind(user, "CallNextHookEx", LRESULT, w.HHOOK, c.c_int, w.WPARAM, w.LPARAM)
module_handle = bind(kernel, "GetModuleHandleW", w.HMODULE, w.LPCWSTR)
foreground = bind(user, "GetForegroundWindow", w.HWND)
window_at = bind(user, "WindowFromPoint", w.HWND, w.POINT)
ancestor = bind(user, "GetAncestor", w.HWND, w.HWND, w.UINT)
process_for_window = bind(user, "GetWindowThreadProcessId", w.DWORD, w.HWND, c.POINTER(w.DWORD))
window_class = bind(user, "GetClassNameW", c.c_int, w.HWND, w.LPWSTR, c.c_int)
clip_open = bind(user, "OpenClipboard", w.BOOL, w.HWND)
clip_close = bind(user, "CloseClipboard", w.BOOL)
clip_formats = bind(user, "EnumClipboardFormats", w.UINT, w.UINT)
clip_get = bind(user, "GetClipboardData", w.HANDLE, w.UINT)
clip_set = bind(user, "SetClipboardData", w.HANDLE, w.UINT, w.HANDLE)
clip_empty = bind(user, "EmptyClipboard", w.BOOL)
clip_owner = bind(user, "GetClipboardOwner", w.HWND)
clip_sequence = bind(user, "GetClipboardSequenceNumber", w.DWORD)
global_size = bind(kernel, "GlobalSize", c.c_size_t, w.HGLOBAL)
global_lock = bind(kernel, "GlobalLock", c.c_void_p, w.HGLOBAL)
global_unlock = bind(kernel, "GlobalUnlock", w.BOOL, w.HGLOBAL)
global_alloc = bind(kernel, "GlobalAlloc", w.HGLOBAL, w.UINT, c.c_size_t)
global_free = bind(kernel, "GlobalFree", w.HGLOBAL, w.HGLOBAL)
send_input = bind(user, "SendInput", w.UINT, w.UINT, c.POINTER(Input), c.c_int)
key_state = bind(user, "GetAsyncKeyState", c.c_short, c.c_int)
create_mutex = bind(kernel, "CreateMutexW", w.HANDLE, c.c_void_p, w.BOOL, w.LPCWSTR)
close_handle = bind(kernel, "CloseHandle", w.BOOL, w.HANDLE)
open_process = bind(kernel, "OpenProcess", w.HANDLE, w.DWORD, w.BOOL, w.DWORD)
process_path = bind(kernel, "QueryFullProcessImageNameW", w.BOOL, w.HANDLE, w.DWORD, w.LPWSTR, c.POINTER(w.DWORD))
mci = bind(winmm, "mciSendStringW", w.DWORD, w.LPCWSTR, w.LPWSTR, w.UINT, w.HWND)


def single_instance():
    c.set_last_error(0)
    handle = create_mutex(None, False, "Local\\DoubleClickDictionary-v1")
    if not handle:
        raise c.WinError(c.get_last_error())
    if c.get_last_error() == 183:  # ERROR_ALREADY_EXISTS
        close_handle(handle)
        return None
    return handle


def window_process(hwnd):
    pid = w.DWORD()
    if hwnd:
        process_for_window(hwnd, c.byref(pid))
    return pid.value


def root_at(x, y):
    hwnd = window_at(w.POINT(x, y))
    return ancestor(hwnd, 2) if hwnd else None  # GA_ROOT


class MouseHook:
    def __init__(self, pressed, double_clicked):
        self.pressed = pressed
        self.double_clicked = double_clicked
        self.last_click = None
        self.down = None
        self.interval = user.GetDoubleClickTime()
        self.half_width = max(2, user.GetSystemMetrics(36) / 2)   # SM_CXDOUBLECLK
        self.half_height = max(2, user.GetSystemMetrics(37) / 2)  # SM_CYDOUBLECLK
        self.callback = HOOKPROC(self._event)
        self.handle = set_mouse_hook(14, self.callback, module_handle(None), 0)  # WH_MOUSE_LL
        if not self.handle:
            raise c.WinError(c.get_last_error())

    def _near(self, first, second):
        return abs(first[0] - second[0]) <= self.half_width and abs(first[1] - second[1]) <= self.half_height

    def _event(self, code, message, pointer):
        try:
            if code == 0 and message in (0x0201, 0x0202, 0x0204):
                event = c.cast(pointer, c.POINTER(MouseEvent)).contents
                if not event.flags & 1:  # LLMHF_INJECTED
                    click = (event.point.x, event.point.y, event.time)
                    if message == 0x0201:  # WM_LBUTTONDOWN
                        self.pressed(*click[:2])
                        self.down = click
                    elif message == 0x0202:  # WM_LBUTTONUP
                        if self.down and self._near(self.down, click) and ((click[2] - self.down[2]) & 0xFFFFFFFF) <= self.interval:
                            previous = self.last_click
                            elapsed = (self.down[2] - previous[2]) & 0xFFFFFFFF if previous else 0
                            if previous and self._near(previous, self.down) and elapsed <= self.interval:
                                self.last_click = None
                                self.double_clicked(*click[:2])
                            else:
                                self.last_click = self.down
                        else:
                            self.last_click = None
                        self.down = None
                    else:
                        self.last_click = self.down = None
                        self.pressed(*click[:2])
        except Exception:
            logging.exception("Mouse callback failed")
        return next_hook(None, code, message, pointer)

    def close(self):
        if self.handle:
            remove_hook(self.handle)
            self.handle = None


@dataclass(frozen=True)
class SelectionRequest:
    x: int
    y: int
    hwnd: int
    pid: int
    clipboard_window: int
    compatibility: bool
    cancelled: threading.Event

    def is_current(self):
        return not self.cancelled.is_set() and foreground() == self.hwnd


def automation_word(auto, request):
    text_role = {auto.ControlType.TextControl, auto.ControlType.EditControl, auto.ControlType.DocumentControl}
    can_copy = False
    for start, from_point in ((lambda: auto.ControlFromPoint(request.x, request.y), True), (auto.GetFocusedControl, False)):
        control = start()
        for _ in range(9 if from_point else 4):
            if not control or not request.is_current():
                break
            if control.IsPassword:
                return "", None
            control_type = control.ControlType
            can_copy = can_copy or (from_point and control_type in text_role)
            pattern = control.GetPattern(auto.PatternId.TextPattern)
            if pattern:
                ranges = pattern.GetSelection()
                if len(ranges) == 1:
                    selection = ranges[0]
                    word = selected_word(selection.GetText(128) or "")
                    if word:
                        rectangles = selection.GetBoundingRectangles()
                        near_point = any(
                            rect.left - 6 <= request.x <= rect.right + 6 and rect.top - 6 <= request.y <= rect.bottom + 6
                            for rect in rectangles
                        )
                        if near_point or (not rectangles and from_point and control_type in text_role):
                            return word, False
            control = control.GetParentControl()
    return "", can_copy


DOCUMENT_APPS = {
    "chrome.exe", "msedge.exe", "firefox.exe", "brave.exe", "opera.exe",
    "acrord32.exe", "acrobat.exe", "sumatrapdf.exe", "foxitpdfreader.exe",
    "winword.exe", "pythonw.exe", "python.exe",
}


def accepts_copy(request, text_role):
    if text_role is None:
        return False
    name = c.create_unicode_buffer(256)
    window_class(request.hwnd, name, len(name))
    if name.value.casefold() in {"consolewindowclass", "cascadia_hosting_window_class", "virtualconsoleclass"}:
        return False
    if text_role:
        return True
    handle = open_process(0x1000, False, request.pid)  # PROCESS_QUERY_LIMITED_INFORMATION
    if not handle:
        return False
    try:
        path = c.create_unicode_buffer(32768)
        size = w.DWORD(len(path))
        return bool(process_path(handle, 0, path, c.byref(size))) and PureWindowsPath(path.value).name.casefold() in DOCUMENT_APPS
    finally:
        close_handle(handle)


PLAIN_CLIPBOARD_FORMATS = {1, 7, 13, 16}  # CF_TEXT, CF_OEMTEXT, CF_UNICODETEXT, CF_LOCALE


def clipboard_bytes(clipboard_format):
    handle = clip_get(clipboard_format)
    size = global_size(handle) if handle else 0
    if not 0 < size <= 8 * 1024 * 1024:
        return None
    pointer = global_lock(handle)
    if not pointer:
        return None
    try:
        return c.string_at(pointer, size)
    finally:
        global_unlock(handle)


def clipboard_snapshot(hwnd):
    if not clip_open(hwnd):
        return None
    try:
        formats = []
        item = clip_formats(0)
        while item:
            if item not in PLAIN_CLIPBOARD_FORMATS:
                return None
            formats.append(item)
            item = clip_formats(item)
        copies = [(item, clipboard_bytes(item)) for item in formats]
        if any(data is None for _, data in copies):
            return None
        return clip_sequence(), copies
    finally:
        clip_close()


def send_copy():
    if any(key_state(key) & 0x8000 for key in (0x10, 0x11, 0x12, 0x5B, 0x5C, 0x43)):
        return False
    events = (Input * 4)()
    for event, (key, flags) in zip(events, ((0x11, 0), (0x43, 0), (0x43, 2), (0x11, 2))):
        event.type = 1  # INPUT_KEYBOARD
        event.data.key = KeyInput(key, 0, flags, 0, 0)
    return send_input(len(events), events, c.sizeof(Input)) == len(events)


def restore_clipboard(copies):
    blocks = {}
    try:
        for item, data in copies:
            handle = global_alloc(2, len(data))  # GMEM_MOVEABLE
            if not handle:
                return
            blocks[item] = handle
            pointer = global_lock(handle)
            if not pointer:
                return
            c.memmove(pointer, data, len(data))
            global_unlock(handle)
        if clip_empty():
            for item, handle in list(blocks.items()):
                if clip_set(item, handle):
                    del blocks[item]
    finally:
        for handle in blocks.values():
            global_free(handle)


def clipboard_word(request):
    if not request.is_current():
        return ""
    snapshot = clipboard_snapshot(request.clipboard_window)
    if snapshot is None:
        return ""
    before, copies = snapshot
    if not request.is_current() or clip_sequence() != before or not send_copy():
        return ""
    deadline = time.monotonic() + 0.32
    while time.monotonic() < deadline:
        sequence = clip_sequence()
        if sequence != before and clip_open(request.clipboard_window):
            try:
                if clip_sequence() != sequence or window_process(clip_owner()) != request.pid:
                    return ""
                data = clipboard_bytes(13)
                restore_clipboard(copies)
                text = data.decode("utf-16-le", errors="ignore").split("\x00", 1)[0] if data else ""
                return selected_word(text) if request.is_current() else ""
            finally:
                clip_close()
        time.sleep(0.012)
    return ""


class SelectionReader:
    def __init__(self, result):
        self.result = result
        self.pending = queue.Queue(maxsize=1)
        threading.Thread(target=self._run, name="Text selection", daemon=True).start()

    def submit(self, request):
        try:
            self.pending.get_nowait()
        except queue.Empty:
            pass
        self.pending.put_nowait(request)

    def _run(self):
        try:
            sys.coinit_flags = 0  # COM multithreaded apartment, on this worker only.
            import uiautomation as auto
        except Exception:
            logging.exception("Unable to initialize Windows UI Automation")
            return
        while True:
            request = self.pending.get()
            if not request.is_current():
                continue
            try:
                word, can_copy = automation_word(auto, request)
                if not word and request.compatibility and accepts_copy(request, can_copy):
                    word = clipboard_word(request)
                if word and request.is_current():
                    self.result(request, word)
            except Exception:
                logging.debug("This control did not expose its selection", exc_info=True)


def stop_audio():
    mci("close dic_audio", None, 0, None)


def play_audio(file):
    stop_audio()
    path = os.fspath(file)
    if mci(f'open "{path}" alias dic_audio', None, 0, None):
        return False
    return mci("play dic_audio from 0", None, 0, None) == 0
