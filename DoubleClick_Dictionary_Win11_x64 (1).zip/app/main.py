import logging
import os
import sys
import tempfile
import threading
from pathlib import Path, PurePosixPath

from PySide6.QtCore import QObject, QPoint, QSettings, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QCursor, QFont, QIcon, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QMenu, QMessageBox, QPushButton, QSystemTrayIcon,
    QToolButton, QVBoxLayout, QWidget,
)

from dictionaries import DictionaryStore, clean_term
from entry_view import EntryView


TITLE = "双击词典"
STATE_DIR = Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "DoubleClickDictionary"
STYLE = """
    QWidget { color: #1c3140; }
    QWidget#main { background: #f3f7f8; }
    QFrame#card, QFrame#popupCard { background: #ffffff; border: 1px solid #d5e0e4; border-radius: 10px; }
    QFrame#popupCard { border-color: #8faaa9; }
    QLabel#title { font-size: 24px; font-weight: 700; }
    QLabel#heading { font-size: 15px; font-weight: 700; }
    QLabel#word { color: #10343b; font-size: 21px; font-weight: 700; }
    QLabel#subtle { color: #4b6574; }
    QLineEdit, QListWidget { background: #ffffff; border: 1px solid #c7d7dd; border-radius: 6px; padding: 6px; }
    QLineEdit:focus { border-color: #157572; }
    QListWidget::item { padding: 6px; }
    QListWidget::item:selected { background: #d9efec; color: #124f4e; }
    QTextBrowser { background: #ffffff; }
    QPushButton { background: #ffffff; border: 1px solid #c7d7dd; border-radius: 6px; padding: 6px 13px; }
    QPushButton:hover { background: #e5f1f1; }
    QPushButton:disabled { color: #728995; background: #f3f7f8; }
    QPushButton#primary { background: #176b68; color: #ffffff; border-color: #176b68; }
    QPushButton#primary:hover { background: #0f5755; }
    QPushButton#primary:disabled { background: #688d8a; border-color: #688d8a; }
    QToolButton { background: transparent; border: 0; border-radius: 4px; color: #4b6574; padding: 1px 6px; font-size: 19px; }
    QToolButton:hover { background: #e5f1f1; }
    QCheckBox { spacing: 6px; }
"""


def label(text, role=""):
    item = QLabel(text)
    item.setTextFormat(Qt.TextFormat.PlainText)
    item.setObjectName(role)
    return item


def icon():
    pixmap = QPixmap(64, 64)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setPen(Qt.PenStyle.NoPen)
    painter.setBrush(QColor("#176b68"))
    painter.drawRoundedRect(1, 1, 62, 62, 13, 13)
    painter.setBrush(Qt.BrushStyle.NoBrush)
    painter.setPen(QPen(QColor("#ffffff"), 3))
    painter.drawRoundedRect(15, 17, 34, 30, 5, 5)
    painter.drawLine(32, 18, 32, 46)
    painter.drawLine(20, 26, 27, 26)
    painter.drawLine(37, 26, 44, 26)
    painter.drawLine(20, 34, 27, 34)
    painter.drawLine(37, 34, 44, 34)
    painter.end()
    return QIcon(pixmap)


class Events(QObject):
    mouse_pressed = Signal(int, int)
    double_clicked = Signal(int, int)
    selected = Signal(object, str)
    progress = Signal(str)
    imported = Signal(object, object)


class Popup(QWidget):
    def __init__(self, load_asset):
        flags = Qt.WindowType.Tool | Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint
        super().__init__(None, flags | Qt.WindowType.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setWindowTitle(TITLE)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        card = QFrame(objectName="popupCard")
        outer.addWidget(card)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(14, 9, 12, 9)
        layout.setSpacing(4)
        top = QHBoxLayout()
        self.word = label("", "word")
        self.word.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        top.addWidget(self.word, 1)
        close_button = QToolButton(text="×", toolTip="关闭释义")
        close_button.setAccessibleName("关闭释义")
        close_button.clicked.connect(self.hide)
        top.addWidget(close_button, 0, Qt.AlignmentFlag.AlignTop)
        layout.addLayout(top)
        self.view = EntryView(load_asset)
        layout.addWidget(self.view, 1)
        self.feedback = label("", "subtle")
        self.feedback.hide()
        layout.addWidget(self.feedback)

    def display(self, word, entries, fallback, anchor):
        screen = QApplication.screenAt(anchor) or QApplication.primaryScreen()
        area = screen.availableGeometry()
        width = min(430, area.width() - 16)
        self.word.setText(word)
        self.word.setWordWrap(True)
        self.feedback.hide()
        self.view.show_entries(entries, fallback)
        self.view.document().setTextWidth(width - 33)
        height = min(360, max(117, int(self.view.document().size().height()) + 83), area.height() - 16)
        x = max(area.left() + 6, min(anchor.x() + 13, area.right() - width - 5))
        y = anchor.y() + 18 if anchor.y() + 18 + height <= area.bottom() else anchor.y() - height - 10
        y = max(area.top() + 6, min(y, area.bottom() - height - 5))
        self.setGeometry(x, y, width, height)
        self.show()
        self.raise_()


class DictionaryWindow(QWidget):
    def __init__(self, application, state_dir, native):
        super().__init__(objectName="main")
        self.native = native
        self.application = application
        self.store = DictionaryStore(state_dir / "dictionaries")
        for stale in self.store.folder.glob("*.tmp*"):
            stale.unlink(missing_ok=True)
        self.catalog = []
        self.settings = QSettings(str(state_dir / "settings.ini"), QSettings.Format.IniFormat)
        self.cancelled = threading.Event()
        self.anchor = QPoint()
        self.shutting_down = threading.Event()
        self.hook = None
        self.reader = None
        self.audio = None
        self.events = Events(self)
        self.popup = Popup(self._load_asset)
        self.events.mouse_pressed.connect(self._mouse_pressed, Qt.ConnectionType.QueuedConnection)
        self.events.double_clicked.connect(self._double_clicked, Qt.ConnectionType.QueuedConnection)
        self.events.selected.connect(self._display_selection, Qt.ConnectionType.QueuedConnection)
        self.events.progress.connect(self._show_status, Qt.ConnectionType.QueuedConnection)
        self.events.imported.connect(self._finish_import, Qt.ConnectionType.QueuedConnection)
        self.setWindowTitle(TITLE)
        self.resize(625, 560)
        self.setMinimumSize(465, 475)
        self.setWindowIcon(application.windowIcon())
        self._build()
        self._tray()
        self._reload()
        if native:
            try:
                self.reader = native.SelectionReader(self.events.selected.emit)
                self.hook = native.MouseHook(self.events.mouse_pressed.emit, self.events.double_clicked.emit)
            except OSError:
                logging.exception("Global mouse hook unavailable")
                self._show_status("双击监听无法启动，仍可在此窗口手动查词。")
        if not self.hook:
            self.toggle.setEnabled(False)
            self.compatibility.setEnabled(False)
            self.tray_toggle.setEnabled(False)
        application.aboutToQuit.connect(self._stop)

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 19, 22, 16)
        layout.setSpacing(13)
        top = QHBoxLayout()
        top.addWidget(label(TITLE, "title"), 1)
        self.toggle = QCheckBox("双击查词")
        self.toggle.setChecked(self.settings.value("double_click", True, bool))
        self.toggle.toggled.connect(self._toggle_changed)
        top.addWidget(self.toggle)
        self.compatibility = QCheckBox("兼容取词")
        self.compatibility.setChecked(self.settings.value("compatibility", False, bool))
        self.compatibility.setToolTip("适用于部分浏览器和 PDF 阅读器。可暂时使用空白或纯文本剪贴板。")
        self.compatibility.toggled.connect(lambda value: self.settings.setValue("compatibility", value))
        top.addWidget(self.compatibility)
        layout.addLayout(top)

        search = QHBoxLayout()
        self.input = QLineEdit(placeholderText="输入单词或短语")
        self.input.setMaxLength(120)
        self.input.setAccessibleName("输入单词或短语")
        self.input.setClearButtonEnabled(True)
        self.input.returnPressed.connect(self._manual_lookup)
        search.addWidget(self.input, 1)
        search_button = QPushButton("查词", objectName="primary")
        search_button.clicked.connect(self._manual_lookup)
        search.addWidget(search_button)
        layout.addLayout(search)

        result_card = QFrame(objectName="card")
        result_layout = QVBoxLayout(result_card)
        result_layout.setContentsMargins(12, 9, 10, 9)
        self.result = EntryView(self._load_asset)
        self.result.setAccessibleName("词条释义")
        self.result.setHtml('<p class="note">导入自己的字典后，双击选中单词即可查词。</p>')
        result_layout.addWidget(self.result)
        layout.addWidget(result_card, 1)
        self.result.word_requested.connect(self._look_up_link)
        self.result.sound_requested.connect(self._play)
        self.popup.view.word_requested.connect(self._look_up_popup_link)
        self.popup.view.sound_requested.connect(self._play)

        dictionaries = QFrame(objectName="card")
        dictionary_layout = QVBoxLayout(dictionaries)
        dictionary_layout.setContentsMargins(12, 10, 12, 11)
        line = QHBoxLayout()
        line.addWidget(label("我的字典", "heading"), 1)
        self.import_button = QPushButton("导入字典", objectName="primary")
        self.import_button.clicked.connect(self._import)
        line.addWidget(self.import_button)
        self.remove_button = QPushButton("移除")
        self.remove_button.clicked.connect(self._remove)
        line.addWidget(self.remove_button)
        dictionary_layout.addLayout(line)
        self.dictionaries = QListWidget()
        self.dictionaries.setAccessibleName("已导入的字典")
        self.dictionaries.setMaximumHeight(110)
        self.dictionaries.currentItemChanged.connect(self._update_remove)
        dictionary_layout.addWidget(self.dictionaries)
        layout.addWidget(dictionaries)
        self.status = label("", "subtle")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)

    def _tray(self):
        self.tray = QSystemTrayIcon(self.windowIcon(), self)
        self.tray.setToolTip(TITLE)
        self.menu = QMenu(self)
        self.menu.addAction("打开词典", self._show_window)
        self.tray_toggle = self.menu.addAction("双击查词")
        self.tray_toggle.setCheckable(True)
        self.tray_toggle.setChecked(self.toggle.isChecked())
        self.tray_toggle.toggled.connect(self.toggle.setChecked)
        self.menu.addSeparator()
        self.menu.addAction("退出", self.application.quit)
        self.tray.setContextMenu(self.menu)
        self.tray.activated.connect(self._tray_activated)
        if QSystemTrayIcon.isSystemTrayAvailable():
            self.tray.show()

    def _tray_activated(self, reason):
        if reason in (QSystemTrayIcon.ActivationReason.Trigger, QSystemTrayIcon.ActivationReason.DoubleClick):
            self._show_window()

    def _show_window(self):
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def _toggle_changed(self, enabled):
        self.settings.setValue("double_click", enabled)
        self.tray_toggle.setChecked(enabled)
        if not enabled:
            self.cancelled.set()
            self.popup.hide()

    def _show_status(self, text):
        self.status.setText(text)

    def _update_remove(self, *_):
        self.remove_button.setEnabled(self.import_button.isEnabled() and self.dictionaries.currentRow() >= 0)

    def _reload(self):
        self.catalog = self.store.list()
        self.dictionaries.clear()
        for dictionary in self.catalog:
            caption = f"{dictionary.name}  ·  {dictionary.entries:,} 条"
            if dictionary.media:
                caption += f"  ·  {dictionary.media:,} 个资源"
            row = QListWidgetItem(caption)
            row.setToolTip(dictionary.source)
            self.dictionaries.addItem(row)
        self._update_remove()
        if self.catalog:
            self._show_status(f"已导入 {len(self.catalog)} 本字典。")
        else:
            self._show_status("支持 MDX、CSV 和 TSV。同名 MDD 放在 MDX 旁边即可。")

    def _import(self):
        names, _ = QFileDialog.getOpenFileNames(
            self, "导入字典", str(Path.home()), "词典 (*.mdx *.csv *.tsv);;所有文件 (*)"
        )
        if not names:
            return
        self.import_button.setEnabled(False)
        self._update_remove()
        self._show_status("正在读取字典…")
        threading.Thread(target=self._prepare_import, args=(names,), name="Dictionary import", daemon=True).start()

    def _prepare_import(self, names):
        prepared, errors = [], []
        for name in names:
            if self.shutting_down.is_set():
                break
            source = Path(name)
            try:
                prepared.append(self.store.prepare(source, self.events.progress.emit))
            except Exception as exc:
                logging.exception("Dictionary import failed")
                errors.append(f"{source.name}：{str(exc) or '无法读取词典文件。'}")
        if not self.shutting_down.is_set():
            self.events.imported.emit(prepared, errors)

    def _finish_import(self, prepared, errors):
        count = 0
        for item in prepared:
            try:
                self.store.commit(item)
                count += 1
                errors.extend(item.warnings)
            except OSError as exc:
                item.temporary.unlink(missing_ok=True)
                errors.append(f"无法保存字典：{exc}")
        self.import_button.setEnabled(True)
        self._reload()
        if count:
            self.result.setHtml('<p class="note">字典已就绪。试试双击选中一个单词。</p>')
        if errors:
            QMessageBox.warning(self, "字典导入", "\n\n".join(errors))

    def _remove(self):
        index = self.dictionaries.currentRow()
        if 0 <= index < len(self.catalog):
            try:
                self.catalog[index].file.unlink()
                self.popup.hide()
                self._reload()
            except OSError as exc:
                QMessageBox.warning(self, "无法移除字典", str(exc))

    def _lookup(self, word):
        try:
            return self.store.lookup(word, self.catalog)
        except Exception:
            logging.exception("Lookup failed")
            self._show_status("无法读取词条。可重新导入对应字典。")
            return [], ""

    def _manual_lookup(self):
        term = clean_term(self.input.text())
        if not term:
            return
        if not self.catalog:
            self.result.setHtml('<p class="note">请先导入自己的字典。</p>')
            return
        self.result.show_entries(*self._lookup(term))

    def _look_up_link(self, word):
        self.input.setText(word)
        self._manual_lookup()

    def _look_up_popup_link(self, word):
        self.popup.display(word, *self._lookup(word), self.anchor)

    def _mouse_pressed(self, x, y):
        self.cancelled.set()
        if self.popup.isVisible() and self.native.root_at(x, y) != int(self.popup.winId()):
            self.popup.hide()

    def _double_clicked(self, x, y):
        if not self.reader or not self.toggle.isChecked() or not self.catalog:
            return
        hwnd = self.native.root_at(x, y)
        pid = self.native.window_process(hwnd)
        if not pid or pid == os.getpid() or self.native.foreground() != hwnd:
            return
        self.cancelled.set()
        self.cancelled = threading.Event()
        self.anchor = QCursor.pos()
        request = self.native.SelectionRequest(x, y, hwnd, pid, int(self.winId()), self.compatibility.isChecked(), self.cancelled)
        QTimer.singleShot(85, lambda: self.reader.submit(request) if request.is_current() else None)

    def _display_selection(self, request, word):
        if request.is_current() and self.toggle.isChecked() and self.catalog:
            self.popup.display(word, *self._lookup(word), self.anchor)

    def _load_asset(self, identifier, url_path):
        try:
            return self.store.media(self.catalog, identifier, url_path)
        except OSError:
            return None
        except Exception:
            logging.exception("Could not load dictionary resource")
            return None

    def _play(self, identifier, url_path):
        if not self.native:
            return
        data = self._load_asset(identifier, url_path)
        played = False
        if data:
            try:
                self.native.stop_audio()
                if not self.audio:
                    self.audio = tempfile.TemporaryDirectory(prefix="dictionary-")
                suffix = PurePosixPath(url_path).suffix.lower()
                file = Path(self.audio.name) / f"pronunciation{suffix}"
                file.write_bytes(data)
                played = self.native.play_audio(file)
            except OSError:
                logging.exception("Could not play dictionary pronunciation")
        if not played:
            message = "这条词典发音无法播放。"
            if self.popup.isVisible():
                self.popup.feedback.setText(message)
                self.popup.feedback.show()
            else:
                self._show_status(message)

    def closeEvent(self, event):
        if self.tray.isVisible():
            self.hide()
            event.ignore()
        else:
            event.accept()
            self.application.quit()

    def _stop(self):
        self.shutting_down.set()
        self.cancelled.set()
        if self.hook:
            self.hook.close()
        self.popup.hide()
        self.tray.hide()
        if self.audio:
            self.native.stop_audio()
            self.audio.cleanup()


def run():
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(filename=STATE_DIR / "dictionary.log", encoding="utf-8", level=logging.WARNING)
    if sys.platform != "win32":
        raise OSError("Windows 11 x64 is required.")
    import windows

    app = QApplication(sys.argv)
    app.setApplicationName(TITLE)
    app.setQuitOnLastWindowClosed(False)
    app.setStyle("Fusion")
    app.setFont(QFont("Segoe UI", 10))
    app.setWindowIcon(icon())
    app.setStyleSheet(STYLE)
    handle = windows.single_instance()
    if not handle:
        QMessageBox.information(None, TITLE, "词典已经在运行。点击任务栏通知区域里的词典图标可打开。")
        return 0
    try:
        window = DictionaryWindow(app, STATE_DIR, windows)
        window.show()
        return app.exec()
    finally:
        windows.close_handle(handle)
