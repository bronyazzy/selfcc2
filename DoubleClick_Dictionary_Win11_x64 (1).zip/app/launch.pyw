import ctypes
import os
import sys
import traceback
from pathlib import Path


def launch():
    vendor = Path(__file__).resolve().parents[1] / "vendor"
    qt = vendor / "PySide6"
    handles = []
    if qt.is_dir():
        for path in (qt, vendor / "shiboken6"):
            handles.append(os.add_dll_directory(str(path)))
        os.environ["QT_PLUGIN_PATH"] = str(qt / "plugins")
        os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = str(qt / "plugins" / "platforms")
    from main import run

    return run()


if __name__ == "__main__":
    try:
        status = launch()
    except Exception as error:
        if sys.platform != "win32":
            raise
        folder = Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "DoubleClickDictionary"
        diagnostic = f"\n\n诊断文件\n{folder / 'startup.log'}"
        try:
            folder.mkdir(parents=True, exist_ok=True)
            (folder / "startup.log").write_text(traceback.format_exc(), encoding="utf-8")
        except OSError:
            diagnostic = ""
        ctypes.windll.user32.MessageBoxW(0, f"词典无法启动。\n{error}{diagnostic}", "双击词典", 0x10)
        status = 1
    raise SystemExit(status)
