from html import escape
from html.parser import HTMLParser
from pathlib import PurePosixPath
from urllib.parse import quote, unquote

from PySide6.QtCore import QByteArray, QUrl, Signal
from PySide6.QtGui import QImage, QTextDocument
from PySide6.QtWidgets import QTextBrowser

from dictionaries import IMAGE_SUFFIXES, SOUND_SUFFIXES, asset_key


SAFE_TAGS = set("a b big blockquote br caption center dd div dl dt em font h1 h2 h3 h4 h5 h6 hr i li ol p pre s small span strong sub sup table tbody td th thead tr u ul".split())
VOID = {"br", "hr"}
OMIT = {"script", "style", "head", "iframe", "object", "svg", "video"}


def media_url(scheme, dictionary, path, suffixes):
    key = asset_key(unquote(path.strip()))
    if key and PurePosixPath(key).suffix in suffixes:
        return f"{scheme}://{dictionary.file.stem}/{quote(key, safe='/')}"
    return ""


class EntryMarkup(HTMLParser):
    def __init__(self, dictionary):
        super().__init__(convert_charrefs=True)
        self.dictionary = dictionary
        self.html = []
        self.omit = None
        self.links = []

    def handle_starttag(self, tag, attrs):
        if self.omit:
            return
        if tag in OMIT:
            self.omit = tag
            return
        attrs = dict(attrs)
        if tag == "img":
            src = media_url("dictasset", self.dictionary, attrs.get("src") or "", IMAGE_SUFFIXES)
            if src and self.dictionary.media:
                self.html.append(f'<img src="{src}" alt="{escape(attrs.get("alt") or "", quote=True)}" />')
        elif tag in {"audio", "source"}:
            src = media_url("dictsound", self.dictionary, attrs.get("src") or "", SOUND_SUFFIXES)
            if src and self.dictionary.media:
                self.html.append(f'<a href="{src}">▶ 发音</a> ')
        elif tag == "a":
            href = (attrs.get("href") or "").strip()
            kind, separator, path = href.partition("://")
            url = ""
            sound = False
            if separator and kind.casefold() in {"entry", "bword"} and path:
                url = "dictword:/" + quote(unquote(path), safe="")
            if separator and kind.casefold() == "sound" and self.dictionary.media:
                url = media_url("dictsound", self.dictionary, path, SOUND_SUFFIXES)
                sound = bool(url)
            self.links.append(bool(url))
            if url:
                self.html.append(f'<a href="{url}">')
                if sound:
                    self.html.append("▶ 发音 ")
        elif tag in SAFE_TAGS:
            retained = []
            for name in ("colspan", "rowspan"):
                val = attrs.get(name) or ""
                if tag in {"td", "th"} and val.isascii() and val.isdigit() and len(val) <= 2:
                    retained.append(f' {name}="{val}"')
            self.html.append(f"<{tag}{''.join(retained)}{' /' if tag in VOID else ''}>")

    def handle_endtag(self, tag):
        if self.omit:
            if tag == self.omit:
                self.omit = None
            return
        if tag == "a":
            if self.links and self.links.pop():
                self.html.append("</a>")
        elif tag in SAFE_TAGS - VOID:
            self.html.append(f"</{tag}>")

    def handle_data(self, data):
        if not self.omit:
            self.html.append(escape(data))


def markup(entries, fallback=""):
    sections = []
    if fallback:
        sections.append(f'<p class="note">按词形 <b>{escape(fallback)}</b> 查找</p>')
    for entry in entries:
        sections.append(f'<p class="source">{escape(entry.dictionary.name)} · {escape(entry.headword)}</p>')
        if entry.is_html:
            parser = EntryMarkup(entry.dictionary)
            parser.feed(entry.definition)
            parser.close()
            sections.extend(parser.html)
        else:
            sections.append(f"<p>{escape(entry.definition).replace(chr(10), '<br/>')}</p>")
        sections.append("<hr/>")
    if sections and sections[-1] == "<hr/>":
        sections.pop()
    return "".join(sections)


class EntryView(QTextBrowser):
    sound_requested = Signal(str, str)
    word_requested = Signal(str)

    def __init__(self, load_asset):
        super().__init__()
        self.load_asset = load_asset
        self.setOpenLinks(False)
        self.setOpenExternalLinks(False)
        self.setFrameShape(self.Shape.NoFrame)
        self.anchorClicked.connect(self._open)
        self.document().setDocumentMargin(4)
        self.document().setDefaultStyleSheet("""
            body { color: #172c3a; font-size: 11pt; }
            p { margin-top: 3px; margin-bottom: 7px; }
            a { color: #086463; }
            .note { color: #4e6574; }
            .source { color: #0d6664; font-size: 10pt; font-weight: 600; margin-bottom: 8px; }
        """)

    def _open(self, url):
        if url.scheme() == "dictsound":
            self.sound_requested.emit(url.host(), url.path(QUrl.ComponentFormattingOption.FullyEncoded))
        elif url.scheme() == "dictword":
            self.word_requested.emit(url.path().lstrip("/"))

    def loadResource(self, kind, url):
        if kind == QTextDocument.ResourceType.ImageResource.value and url.scheme() == "dictasset":
            data = self.load_asset(url.host(), url.path(QUrl.ComponentFormattingOption.FullyEncoded))
            if data:
                image = QImage.fromData(QByteArray(data))
                if not image.isNull():
                    return image.scaledToWidth(350) if image.width() > 350 else image
        return None

    def show_entries(self, entries, fallback):
        if entries:
            self.setHtml(markup(entries, fallback))
        else:
            self.setHtml('<p class="note">已导入的字典里没有这个词。</p>')
        self.verticalScrollBar().setValue(0)
