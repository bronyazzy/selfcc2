@echo off
setlocal
if not exist "%~dp0runtime\pythonw.exe" (
    echo Extract all files from the ZIP before running Start.cmd.
    pause
    exit /b 1
)
start "" "%~dp0runtime\pythonw.exe" -B "%~dp0app\launch.pyw"
