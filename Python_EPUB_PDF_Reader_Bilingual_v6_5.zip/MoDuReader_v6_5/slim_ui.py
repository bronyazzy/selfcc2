"""A single reading toolbar; advanced controls stay available under More.

This shell is deliberately independent from F8 (definition only) and F9
(windowed book + definition). Old layout/compact preferences are preserved.
"""
import os
import sys
from PySide6.QtGui import QAction, QFont
from PySide6.QtWidgets import QMenu, QToolBar, QToolButton


class SlimReaderMixin:
    def __init__(self, state):
        prefs = state.data['preferences']
        self.minimal_chrome = prefs.get('minimal_chrome', True) is not False
        self._compatible_launcher = (os.environ.get('MODU_COMPATIBLE_EPUB') == '1'
                                     or '--compatible-epub' in sys.argv)
        self._search_shown = False
        self._layout_shown = False
        self._pdf_tools_shown = False
        # Existing users keep their selected layout; new users start bilingual.
        prefs.setdefault('epub_layout', {'mode': 'parallel', 'english_percent': 55,
                                        'line_height': 1.5, 'content_width': 0})
        prefs.setdefault('font_size', 16)
        super().__init__(state)
        self.setWindowTitle('墨读 6.5 · EPUB / PDF 双语金融阅读器')

    def _build_ui(self):
        super()._build_ui()
        toolbar = self.findChild(QToolBar, 'readerToolbar')
        self._full_toolbar_actions = list(toolbar.actions())
        self.parallel_action = self._action('双栏对照', self.toggle_parallel, 'F6', checkable=True)
        self.parallel_action.setToolTip('切换 EPUB 左右对照 / 原书排版。F6；不生成原书没有的译文。')
        self.slim_action = self._action('简洁界面', self.set_minimal_chrome, checkable=True)
        self.slim_action.setChecked(self.minimal_chrome)
        self.layout_controls_action = self._action('显示排版设置', self.toggle_layout_controls, checkable=True)
        self.pdf_controls_action = self._action('显示 PDF 工具', self.toggle_pdf_controls, checkable=True)
        self.search_controls_action = self._action('显示搜索栏', self.toggle_search_controls, checkable=True)
        self.more_menu = QMenu('更多', self)
        # Actions are reused, so the established shortcuts continue to work.
        for action in self._full_toolbar_actions:
            if not action.isSeparator() and toolbar.widgetForAction(action) is not self.font_label:
                self.more_menu.addAction(action)
        self.more_menu.addSeparator()
        for action in (self.parallel_action, self.layout_controls_action, self.pdf_controls_action,
                       self.search_controls_action, self.slim_action):
            self.more_menu.addAction(action)
        self.more_menu.addSeparator()
        if self.dictionary_dock is not None:
            dictionary_menu = self.more_menu.addMenu('词典与词库')
            dictionary_menu.addAction('导入 MDX / MDD…', self.dictionary_dock.mdict_panel.choose_import)
            dictionary_menu.addAction('管理 MDX 词典…', self.dictionary_dock.mdict_panel.manage_dictionaries)
            dictionary_menu.addAction('导入英汉词库 CSV…', self.dictionary_dock.choose_import)
            dictionary_menu.addAction('临时查词…', self.dictionary_dock.prompt_query)
        for action in self.menuBar().actions():
            if action.menu() is not None:
                self.more_menu.addMenu(action.menu())
        self.more_action = QAction('更多', self)
        self.more_action.setMenu(self.more_menu)
        lookup = next((a for a in self._full_toolbar_actions if a.text() == '查所选词'), None)
        if lookup:
            lookup.setText('查词')
            lookup.setToolTip('查询选中单词；未选词时弹出输入框。Ctrl+E')
        self._slim_toolbar_actions = [
            self._full_toolbar_actions[0], self.prev_action, self.next_action,
            *[a for a in self._full_toolbar_actions if a.text() in ('A−', 'A+')],
            self.parallel_action,
        ]
        if lookup:
            self._slim_toolbar_actions.append(lookup)
        if self.dictionary_dock is not None:
            self._slim_toolbar_actions.append(self.dictionary_dock.compact_action)
        self._slim_toolbar_actions += [self.boss_action, self.more_action]
        sidebar_visible = self.store.data['preferences'].get('sidebar_visible', not self.minimal_chrome)
        self.sidebar.setVisible(bool(sidebar_visible))
        self.sidebar_action.setChecked(bool(sidebar_visible))
        self._rebuild_reading_toolbar()
        self._apply_shell_visibility()
        self._sync_slim_actions()

    def _rebuild_reading_toolbar(self):
        toolbar = self.findChild(QToolBar, 'readerToolbar')
        for action in list(toolbar.actions()):
            toolbar.removeAction(action)
        actions = self._slim_toolbar_actions if self.minimal_chrome else self._full_toolbar_actions
        toolbar.addActions(actions)
        if not self.minimal_chrome:
            toolbar.addAction(self.parallel_action)
            toolbar.addAction(self.more_action)
        more_button = toolbar.widgetForAction(self.more_action)
        if isinstance(more_button, QToolButton):
            more_button.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)

    def _apply_shell_visibility(self):
        if self.boss_active or self._focus_states is not None:
            return
        self.menuBar().setVisible(not self.minimal_chrome)
        self.reading_header.setVisible(not self.minimal_chrome or self._search_shown)
        self.layout_toolbar.setVisible(self.book is not None and
                                       (not self.minimal_chrome or self._layout_shown))
        self.pdf_toolbar.setVisible(self.pdf_book is not None and
                                    (not self.minimal_chrome or self._pdf_tools_shown))

    def _sync_slim_actions(self):
        if not hasattr(self, 'parallel_action'):
            return
        self.parallel_action.setEnabled(self.book is not None and self.pdf_book is None)
        self.parallel_action.setChecked(self.layout_settings.mode in {'parallel', 'compatible'})
        self.layout_controls_action.setEnabled(self.book is not None)
        self.pdf_controls_action.setEnabled(self.pdf_book is not None)

    def set_minimal_chrome(self, enabled):
        if self.boss_active:
            return
        self.minimal_chrome = bool(enabled)
        self.slim_action.setChecked(self.minimal_chrome)
        self._rebuild_reading_toolbar()
        self._apply_shell_visibility()
        self._save_timer.start()

    def toggle_parallel(self, enabled):
        if self.book is None or self.pdf_book is not None:
            return
        if enabled:
            # Preserve the no-WebEngine guarantee of the compatible launcher.
            native = self._compatible_launcher or self._force_compatible or self.layout_settings.mode in {'compatible', 'simple'}
            self.set_layout(mode='compatible' if native else 'parallel',
                            english_percent=self.layout_settings.english_percent,
                            line_height=self.layout_settings.line_height or 1.5)
        elif self._compatible_launcher:
            self.statusBar().showMessage('当前以兼容模式启动；原书排版请使用普通启动脚本。', 7000)
        else:
            self.set_layout(mode='publisher')
        self._sync_slim_actions()

    def toggle_layout_controls(self, shown):
        self._layout_shown = bool(shown)
        self.layout_controls_action.setChecked(self._layout_shown)
        self._apply_shell_visibility()

    def toggle_pdf_controls(self, shown):
        self._pdf_tools_shown = bool(shown)
        self.pdf_controls_action.setChecked(self._pdf_tools_shown)
        self._apply_shell_visibility()

    def toggle_search_controls(self, shown):
        self._search_shown = bool(shown)
        self.search_controls_action.setChecked(self._search_shown)
        self._apply_shell_visibility()
        if shown and not self.boss_active:
            self.search_edit.setFocus()

    def focus_search(self):
        if not self.boss_active and self.minimal_chrome:
            self.toggle_search_controls(True)
        return super().focus_search()

    def _focus_pdf_page(self):
        if not self.boss_active and self.minimal_chrome:
            self.toggle_pdf_controls(True)
        return super()._focus_pdf_page()

    def open_book(self, filename):
        result = super().open_book(filename)
        self._apply_shell_visibility()
        self._sync_slim_actions()
        return result

    def set_layout(self, **values):
        result = super().set_layout(**values)
        self._sync_slim_actions()
        return result

    def update_controls(self):
        super().update_controls()
        self._sync_slim_actions()

    def set_boss_mode(self, enabled):
        super().set_boss_mode(enabled)
        if not self.boss_active:
            self._apply_shell_visibility()

    def exit_focus(self):
        super().exit_focus()
        self._apply_shell_visibility()

    def show_welcome(self):
        doc = self.browser.document()
        doc.setDefaultFont(QFont(self.reading_font, self.font_size))
        doc.setDefaultStyleSheet(self.document_css())
        doc.setDocumentMargin(32)
        self.browser.setHtml('''<p><b>墨读 · 双语金融阅读</b></p>
            <p>打开或拖入 EPUB / PDF。双击英文查词，选中短语后按 Ctrl+E。</p>
            <p>双栏对照 F6　·　只看释义 F8　·　老板模式 F9</p>
            <p>从英文栏开始跨段选择，Ctrl+C 连续复制英文。<br>
            老板模式保留窗口边框，只显示书本和释义；F9 / Esc 恢复。</p>
            <p>在「更多」调整栏宽、导入 MDX / MDD 或显示目录。<br>
            包内 parallel_demo.epub 可直接试读，pdf_demo.pdf 可测试 PDF。</p>''')

    def _extend_saved_state(self):
        super()._extend_saved_state()
        self.store.data['preferences']['minimal_chrome'] = self.minimal_chrome
        # Sidebar is temporarily hidden in boss/fullscreen modes, not a preference change.
        if not self.boss_active and self._focus_states is None:
            self.store.data['preferences']['sidebar_visible'] = not self.sidebar.isHidden()
