"""Qt-only language metadata and copying, including the no-WebEngine path.

Host-generated nonce markers exist only in the transient HTML, and are removed
before the QTextDocument is attached to the visible browser. Custom character
format properties survive reflow without matching text or guessing languages.
"""
from __future__ import annotations
from PySide6.QtCore import QMimeData, Qt
from PySide6.QtGui import QColor, QKeySequence, QPalette, QTextCursor, QTextFormat
from PySide6.QtWidgets import QApplication, QMenu, QTextEdit
from bilingual_copy import CopyPiece, MAX_COPY_CHARS, combine_pieces

LANG_PROPERTY = QTextFormat.Property.UserProperty.value + 631
PARAGRAPH_PROPERTY = LANG_PROPERTY + 1


def install_metadata(document, specs):
    deletions = []
    for spec in specs:
        start = document.find(spec['start'])
        end = document.find(spec['end'])
        if start.isNull() or end.isNull() or start.selectionEnd() > end.selectionStart():
            raise ValueError('单语言复制定位标记不完整；未按字符猜测语言。')
        cursor = QTextCursor(document)
        cursor.setPosition(start.selectionEnd())
        cursor.setPosition(end.selectionStart(), QTextCursor.MoveMode.KeepAnchor)
        from PySide6.QtGui import QTextCharFormat
        fmt = QTextCharFormat()
        fmt.setProperty(LANG_PROPERTY, spec['lang'])
        fmt.setProperty(PARAGRAPH_PROPERTY, spec['para'])
        cursor.mergeCharFormat(fmt)
        deletions.extend([(start.selectionStart(),start.selectionEnd()),(end.selectionStart(),end.selectionEnd())])
    cursor = QTextCursor(document); cursor.beginEditBlock()
    try:
        for start,end in sorted(deletions,reverse=True):
            cursor.setPosition(start);cursor.setPosition(end,QTextCursor.MoveMode.KeepAnchor)
            cursor.removeSelectedText()
    finally: cursor.endEditBlock()
    spans = []
    block = document.begin()
    while block.isValid():
        iterator = block.begin()
        while not iterator.atEnd():
            fragment = iterator.fragment()
            if fragment.isValid():
                fmt=fragment.charFormat();lang=fmt.property(LANG_PROPERTY)
                if lang in ('en','zh'):
                    spans.append((fragment.position(),fragment.position()+fragment.length(),lang,str(fmt.property(PARAGRAPH_PROPERTY))))
            iterator += 1
        block = block.next()
    return spans


class BilingualCopyMixin:
    """Works with QTextBrowser, without changing the underlying selection range."""
    def init_bilingual_copy(self):
        self.copy_lock = True
        self.copy_specs = ()
        self.copy_mapping_error = ""
        self.copy_spans = []
        self._copy_mouse_start = None
        self._copy_mouse_range = None
        self._copy_pressed = False
        self._copy_original_colors = None
        self._copy_highlighting = False
        self.selectionChanged.connect(self._update_copy_highlight)

    def attach_copy_metadata(self, document):
        self.copy_mapping_error = ''
        try:
            self.copy_spans = install_metadata(document,self.copy_specs) if self.copy_specs else []
        except (ValueError,RuntimeError) as exc:
            # Copy enhancements must not blank the book. Remove every remaining
            # host marker, keep the visible text, and refuse uncertain filtering.
            self.copy_spans=[]
            self.copy_mapping_error='单语言定位失败；可用“复制双语 / 原始选区”，请重载本章。'+str(exc)
            for spec in self.copy_specs:
                for key in ('start','end'):
                    cursor=document.find(spec[key])
                    while not cursor.isNull():
                        cursor.removeSelectedText();cursor=document.find(spec[key])
            self._copy_notice(self.copy_mapping_error)
        self._copy_mouse_start = self._copy_mouse_range = None
        self._copy_pressed = False
        self._reset_copy_highlight()

    def setHtml(self, markup):
        self.copy_spans=[];self.copy_specs=();self.copy_mapping_error=""
        self._copy_mouse_range=None
        self._reset_copy_highlight()
        return super().setHtml(markup)

    def _copy_language_at(self,pos):
        for start,end,lang,_ in self.copy_spans:
            if start <= pos < end: return lang
        return ''

    def _copy_bounds(self):
        cursor=self.textCursor()
        if not cursor.hasSelection(): return None
        if self._copy_mouse_range is not None:
            a,b=self._copy_mouse_range
            origin=a
        else:
            a,b=cursor.anchor(),cursor.position();origin=a
            # Qt changes a multi-row cell selection into a rectangular table
            # selection. cursor.position() can then point to the START of the
            # final cell, although that whole cell is selected. Reading only
            # anchor()/position() silently dropped the final English paragraph.
            # Mouse drags retain their precise endpoint through the branch above.
            if cursor.hasComplexSelection():
                table=cursor.currentTable()
                first_row,row_count,first_column,column_count=cursor.selectedTableCells()
                if table is not None and row_count>0 and column_count>0:
                    first=table.cellAt(first_row,first_column)
                    last=table.cellAt(first_row+row_count-1,first_column+column_count-1)
                    if first.isValid() and last.isValid():
                        a=first.firstCursorPosition().position()
                        b=last.lastCursorPosition().position()
        lang=self._copy_language_at(origin)
        # Use the retained drag direction. Qt may normalize a backwards table
        # drag into a forward rectangular selection while its actual anchor is
        # still immediately after the final English character.
        backwards=(self._copy_mouse_range[0]>self._copy_mouse_range[1]
                   if self._copy_mouse_range is not None else cursor.anchor()>cursor.position())
        if not lang and backwards:
            lang=self._copy_language_at(max(0,origin-1))
        return min(a,b),max(a,b),lang

    def lookup_selection_text(self):
        bounds=self._copy_bounds()
        if bounds is None or bounds[1]-bounds[0]>20000:return ''
        try:return self.copy_selection_text()
        except (ValueError,RuntimeError):return ''

    def copy_selection_text(self,language='auto'):
        if self.copy_mapping_error and language!='both':raise ValueError(self.copy_mapping_error)
        bounds=self._copy_bounds()
        if bounds is None: return ''
        start,end,origin=bounds
        lang=(origin if self.copy_lock else '') if language=='auto' else language
        if lang not in ('en','zh'):
            text=self.textCursor().selection().toPlainText()
            if len(text)>MAX_COPY_CHARS: raise ValueError('所选内容超过 400 万字符，请分段复制。')
            return text
        pieces=[];previous_end=None;previous_para=None
        for a,b,unit_lang,para in self.copy_spans:
            if b<=start or a>=end or unit_lang!=lang: continue
            # Preserve paragraph breaks inside one language unit, but never
            # copy the opposite-language cell between two sentence groups.
            if previous_para==para and previous_end is not None and previous_end<a:
                gap=QTextCursor(self.document());gap.setPosition(previous_end)
                gap.setPosition(a,QTextCursor.MoveMode.KeepAnchor)
                value=gap.selectedText()
                if value and not value.strip('\u2029\u2028\n\r\t '):
                    pieces.append(CopyPiece(value,unit_lang,para))
            cursor=QTextCursor(self.document())
            cursor.setPosition(max(start,a));cursor.setPosition(min(end,b),QTextCursor.MoveMode.KeepAnchor)
            pieces.append(CopyPiece(cursor.selectedText(),unit_lang,para))
            previous_end=min(end,b);previous_para=para
        return combine_pieces(pieces,lang)

    def copy_for_language(self,language='auto'):
        try:
            text=self.copy_selection_text(language)
            if text: QApplication.clipboard().setText(text)
            else: self._copy_notice('所选范围中没有可复制的该语言文字；剪贴板未改变。')
        except (ValueError,RuntimeError) as exc: self._copy_notice(str(exc))

    def _copy_notice(self,text):
        window=self.window()
        if hasattr(window,'statusBar'): window.statusBar().showMessage(text,6000)

    def copy(self):
        self.copy_for_language('auto')

    def createMimeDataFromSelection(self):
        mime=QMimeData()
        try: text=self.copy_selection_text()
        except ValueError as exc: self._copy_notice(str(exc));return mime
        if text: mime.setText(text)
        return mime

    def _reset_copy_highlight(self):
        if self._copy_original_colors:
            palette=self.palette()
            palette.setColor(QPalette.ColorRole.Highlight,self._copy_original_colors[0])
            palette.setColor(QPalette.ColorRole.HighlightedText,self._copy_original_colors[1])
            self.setPalette(palette);self._copy_original_colors=None
        self.setExtraSelections([])

    def _update_copy_highlight(self):
        if self._copy_highlighting:return
        self._copy_highlighting=True
        try:
            bounds=self._copy_bounds()
            if not self.copy_lock or bounds is None or bounds[2] not in ('en','zh'):
                self._reset_copy_highlight();return
            start,end,lang=bounds
            palette=self.palette()
            if self._copy_original_colors is None:
                self._copy_original_colors=(palette.color(QPalette.ColorRole.Highlight),palette.color(QPalette.ColorRole.HighlightedText))
            palette.setColor(QPalette.ColorRole.Highlight,QColor(0,0,0,0))
            palette.setColor(QPalette.ColorRole.HighlightedText,palette.color(QPalette.ColorRole.Text))
            self.setPalette(palette)
            selections=[]
            for a,b,unit_lang,para in self.copy_spans:
                if unit_lang!=lang or b<=start or a>=end:continue
                selection=QTextEdit.ExtraSelection()
                selection.cursor=QTextCursor(self.document())
                selection.cursor.setPosition(max(a,start))
                selection.cursor.setPosition(min(b,end),QTextCursor.MoveMode.KeepAnchor)
                selection.format.setBackground(self._copy_original_colors[0])
                selection.format.setForeground(self._copy_original_colors[1])
                selections.append(selection)
            self.setExtraSelections(selections)
        finally:self._copy_highlighting=False

    def _copy_press(self,event):
        if event.button()==Qt.MouseButton.LeftButton:
            pos=self.cursorForPosition(event.pos()).position()
            if event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                pos=self.textCursor().anchor()
            self._copy_mouse_start=pos;self._copy_mouse_range=None;self._copy_pressed=True

    def _copy_move(self,event):
        if self._copy_pressed and self._copy_mouse_start is not None and self.textCursor().hasSelection():
            end=self.cursorForPosition(event.pos()).position()
            self._copy_mouse_range=(self._copy_mouse_start,end)
            self._update_copy_highlight()

    def _copy_release(self,event):
        if event.button()==Qt.MouseButton.LeftButton:
            self._copy_move(event);self._copy_pressed=False

    def _copy_key(self,event):
        if event.matches(QKeySequence.StandardKey.Copy):
            self.copy_for_language();event.accept();return True
        # Keyboard selection has its own precise Qt anchor; do not reuse an old
        # drag's endpoints (including when Ctrl+A is pressed after a drag).
        self._copy_mouse_range=None;self._copy_mouse_start=None
        return False

    def add_copy_actions(self,menu):
        selected=self.textCursor().hasSelection()
        for label,lang in [('复制（按起选语言）','auto'),('只复制英文','en'),('只复制中文','zh'),('复制双语 / 原始选区','both')]:
            action=menu.addAction(label);action.setEnabled(selected)
            action.triggered.connect(lambda _=False,l=lang:self.copy_for_language(l))
        menu.addSeparator()
        action=menu.addAction('全选本章');action.triggered.connect(self.selectAll)
