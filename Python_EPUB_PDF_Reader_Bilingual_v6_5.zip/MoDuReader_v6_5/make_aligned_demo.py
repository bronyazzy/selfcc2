"""Build the original, freely reusable bilingual finance acceptance sample."""
from html import escape
from pathlib import Path
import zipfile

PAIRS = [
 ('A bond represents a loan to an issuer. The issuer promises payments under the bond terms.',
  '债券代表投资者向发行人提供的一笔借款。发行人承诺按照债券条款付款。'),
 ('Duration measures sensitivity to a change in yield. A longer duration usually means a larger price response. Credit risk also matters.',
  '久期衡量价格对收益率变动的敏感程度，久期越长，价格通常越敏感。信用风险同样重要。'),
 ('Liquidity is the ability to trade promptly at a reasonable cost. A liquid market can still experience price volatility.',
  '流动性是以合理成本及时完成交易的能力。即使市场流动性充足，价格仍可能波动。'),
 ('A loan-to-value ratio compares a loan balance with collateral value. If collateral value falls, the ratio rises when the loan balance is unchanged.',
  '贷款价值比比较贷款余额与抵押品价值。如果抵押品价格下跌而贷款余额不变，这个比率就会上升。'),
 ('A fixed coupon note pays coupons subject to its terms. The coupon does not remove downside risk from the linked underlying asset.',
  '固定票息票据按条款支付票息。票息并不会消除挂钩资产带来的下行风险。'),
 ('Copy several English paragraphs by starting the selection in the English column. Press Ctrl+C to keep only the selected English text.',
  '从英文栏开始选择，可以连续选取多段英文。按 Ctrl+C 即可只复制选中的英文内容。'),
]

def build(path):
 body='<h1>Financial reading / 金融双语试读</h1>'
 for en,zh in PAIRS:
  body+=f'<div class="pair"><p lang="en">{escape(en)}</p><p lang="zh">{escape(zh)}</p></div>'
 doc='''<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml"><head><title>Financial reading</title><style>
 body{font-family:serif;line-height:1.5}.pair{display:grid;grid-template-columns:55% 45%;gap:1em;margin:1em 0}.pair p{margin:0}h1{font-size:2em}
 </style></head><body>'''+body+'</body></html>'
 container='''<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/book.opf" media-type="application/oebps-package+xml"/></rootfiles></container>'''
 opf='''<?xml version="1.0" encoding="utf-8"?><package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="id"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="id">modu-65-aligned-finance-demo</dc:identifier><dc:title>金融双语试读</dc:title><dc:language>en</dc:language><dc:creator>MoDuReader</dc:creator><meta property="dcterms:modified">2026-11-04T00:00:00Z</meta></metadata><manifest><item id="chapter" href="chapter.xhtml" media-type="application/xhtml+xml"/><item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/></manifest><spine><itemref idref="chapter"/></spine></package>'''
 nav='''<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops"><head><title>目录</title></head><body><nav epub:type="toc"><ol><li><a href="chapter.xhtml">金融双语试读</a></li></ol></nav></body></html>'''
 with zipfile.ZipFile(path,'w') as z:
  z.writestr('mimetype','application/epub+zip',compress_type=zipfile.ZIP_STORED)
  for name,data in [('META-INF/container.xml',container),('OEBPS/book.opf',opf),('OEBPS/chapter.xhtml',doc),('OEBPS/nav.xhtml',nav)]:
   z.writestr(name,data,compress_type=zipfile.ZIP_DEFLATED)

if __name__=='__main__':
 build(Path(__file__).with_name('aligned_finance_demo.epub'))
