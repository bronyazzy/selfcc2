"""Lookup regressions for the compact-first reading experience."""
from __future__ import annotations

import importlib.util
import os
from pathlib import Path
import tempfile
import unittest

from dictionary_core import DictionaryEngine, Entry, entry_plain_text


class DefinitionCopyTests(unittest.TestCase):
    def test_complete_entry_not_just_chinese_summary(self):
        entry = Entry('carry', 'ˈkæri', finance='持有收益', translation='携带',
                      definition='Income less the costs of holding a position.',
                      examples=(('Carry can be negative.', '持有收益可以为负。'),))
        copied = entry_plain_text(entry)
        for text in ('/ˈkæri/', '持有收益', '携带', 'Income less',
                     'Carry can be negative.', '持有收益可以为负。'):
            self.assertIn(text, copied)
        self.assertLess(copied.index('持有收益'), copied.index('携带'))
        general_first = entry_plain_text(entry, False)
        self.assertLess(general_first.index('携带'), general_first.index('持有收益'))

    def test_missing_phonetic_and_repeated_sense(self):
        copied = entry_plain_text(Entry('risk', finance='风险', translation='风险'))
        self.assertNotIn('//', copied)
        self.assertEqual(copied.count('风险'), 1)

    def test_financial_abbreviations_have_chinese_and_full_term_ipa(self):
        with_engine = DictionaryEngine()
        try:
            for query, word in [('FCN', 'fixed coupon note'),
                                ('LTV', 'loan to value'),
                                ('HIBOR', 'Hong Kong interbank offered rate'),
                                ('KI', 'knock in'), ('KO', 'knock out'),
                                ('YTW', 'yield to worst'), ('YTC', 'yield to call')]:
                with self.subTest(query=query):
                    entry = with_engine.lookup(query).entries[0]
                    self.assertEqual(entry.word, word)
                    self.assertTrue(entry.phonetic)
                    self.assertRegex(entry.finance, '[\u4e00-\u9fff]')
        finally:
            with_engine.close()


HAS_QT = importlib.util.find_spec('PySide6') is not None
if HAS_QT:
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    from PySide6.QtWidgets import QApplication, QMainWindow
    from PySide6.QtTest import QTest
    from dictionary_ui import DictionaryDock
    from mdict_core import build_index


@unittest.skipUnless(HAS_QT, 'PySide6 unavailable; desktop lookup tests not run')
class CompactFirstGuiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setQuitOnLastWindowClosed(False)

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.directory = Path(self.temp.name)
        self.window = QMainWindow()
        self.dock = DictionaryDock(self.directory, {}, self.window)
        self.dock.show()
        self.window.show()
        QTest.qWait(20)

    def tearDown(self):
        self.dock.shutdown()
        self.window.close()
        QTest.qWait(10)
        self.temp.cleanup()

    def test_fresh_default_is_compact_and_full_mode_still_available(self):
        self.assertTrue(self.dock.compact_active)
        self.assertTrue(self.dock.query_edit.isHidden())
        self.dock.lookup('equity')
        self.assertEqual(self.dock.result_view.document().documentMargin(), 8)
        self.dock.set_compact(False)
        self.assertFalse(self.dock.query_edit.isHidden())
        self.assertEqual(self.dock.result_view.document().documentMargin(), 16)

    def test_saved_expanded_preference_wins(self):
        other = DictionaryDock(self.directory / 'other', {'dictionary_compact': False}, self.window)
        try:
            self.assertFalse(other.compact_active)
        finally:
            other.shutdown()
            other.deleteLater()

    def test_copy_current_keeps_original_bilingual_example(self):
        self.dock.lookup('equity')
        self.dock.copy_current()
        copied = QApplication.clipboard().text()
        self.assertIn('The company raised capital by issuing equity.', copied)
        self.assertIn('公司通过发行股权筹集资本。', copied)
        self.assertIn('ˈekwɪti', copied)

    def test_miss_does_not_show_previous_word(self):
        self.dock.lookup('equity')
        self.dock.lookup('unlistedzzz')
        text = self.dock.result_view.toPlainText()
        self.assertIn('未收录', text)
        self.assertIn('unlistedzzz', text)
        self.assertNotIn('所有者权益', text)

    def test_heading_size_is_uniform_in_full_and_compact_views(self):
        for compact in (False, True):
            self.dock.set_compact(compact)
            self.dock.lookup('equity')
            document = self.dock.result_view.document()
            heading = document.find('equity').charFormat().font().pointSizeF()
            body = document.find('所有者权益').charFormat().font().pointSizeF()
            self.assertEqual(heading, body)

    def test_mdd_resource_loading_survives_compact_padding_and_full_toggle(self):
        root = Path(__file__).resolve().parents[1]
        panel = self.dock.mdict_panel
        plan = build_index(root / 'examples/mdict_demo/FinanceDemo.mdx', panel.library.directory)
        panel.library.commit(plan)
        panel.refresh_dictionaries()
        self.dock.tabs.setCurrentWidget(panel)
        for compact, margin in ((True, 8), (False, 16), (True, 8)):
            self.dock.set_compact(compact)
            self.dock.lookup('equity')
            self.assertIn('股权', panel.browser.toPlainText())
            self.assertIn('ˈekwɪti', panel.browser.toPlainText())
            self.assertEqual(panel.browser.document().documentMargin(), margin)
            self.assertTrue(panel.browser.images.cache)
            self.assertTrue(all(not image.error for image in panel.browser.images.cache.values()))


if __name__ == '__main__':
    unittest.main()
