"""Real-browser regressions; skipped explicitly if Chromium cannot launch."""
import unittest
import test_bilingual_browser as browser
from browser_harness import GEOMETRY
from test_alignment_refinements import SOURCE, EN


@unittest.skipUnless(browser.AVAILABLE, '没有 Playwright')
class CopyBoundaryBrowserTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        browser.BilingualBrowserTests.setUpClass.__func__(cls)
    @classmethod
    def tearDownClass(cls):
        browser.BilingualBrowserTests.tearDownClass.__func__(cls)
    setUp = browser.BilingualBrowserTests.setUp
    select = browser.BilingualBrowserTests.select
    load_template = browser.BilingualBrowserTests.load_template

    def test_element_boundary_english_selection_does_not_reuse_chinese_pointer(self):
        self.page.locator('[data-mr-lang="zh"]').first.dispatch_event('pointerdown', {'button': 0})
        self.page.locator('[data-mr-lang="zh"]').first.dispatch_event('pointerup', {'button': 0})
        result = self.page.evaluate('''()=>{
          const units=[...document.querySelectorAll('[data-mr-lang="en"]')];
          const first=units[0],last=units.at(-1);
          const index=n=>[...n.parentNode.childNodes].indexOf(n);
          getSelection().setBaseAndExtent(first.parentNode,index(first),last.parentNode,index(last)+1);
          return window.__modu.copyText();
        }''')
        self.assertEqual(result['language'], 'en')
        self.assertIn('A second paragraph', result['text'])
        self.assertNotIn('风险', result['text'])

    def test_reverse_element_boundary_english_selection(self):
        result = self.page.evaluate('''()=>{
          const units=[...document.querySelectorAll('[data-mr-lang="en"]')];
          const first=units[0],last=units.at(-1),index=n=>[...n.parentNode.childNodes].indexOf(n);
          getSelection().setBaseAndExtent(last.parentNode,index(last)+1,first.parentNode,index(first));
          return window.__modu.copyText();
        }''')
        self.assertEqual(result['language'], 'en')
        self.assertIn('A second paragraph', result['text'])
        self.assertNotIn('风险', result['text'])

    def test_unmarked_selection_never_inherits_old_pointer_language(self):
        unit = self.page.locator('[data-mr-lang="en"]').first
        unit.dispatch_event('pointerdown', {'button': 0}); unit.dispatch_event('pointerup', {'button': 0})
        result = self.page.evaluate('''()=>{
          const p=document.createElement('p');p.textContent='Unmarked prose with 中文 quotation.';document.body.append(p);
          const range=document.createRange();range.selectNodeContents(p);
          getSelection().removeAllRanges();getSelection().addRange(range);
          return window.__modu.copyText();
        }''')
        self.assertEqual(result['text'], 'Unmarked prose with 中文 quotation.')
        self.assertEqual(result['language'], 'both')

    def test_unequal_groups_align_tops_and_copy_original_paragraphs(self):
        self.load_template(SOURCE)
        for width in (1200, 680):
            self.page.set_viewport_size({'width': width, 'height': 800})
            rows = self.page.evaluate(GEOMETRY)
            self.assertEqual(len(rows), 3)
            for row in rows:
                self.assertAlmostEqual(row['ey'], row['zy'], delta=.5)
            self.assertEqual(self.select()['text'], EN + '\n\nThe bond trades at 99.5.')
