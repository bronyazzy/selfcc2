"""Regression checks for unequal sentence grouping and native English copying."""
import unittest
from unittest.mock import patch
from lxml import html as LH
from bilingual_alignment import (
    AlignmentError, PairText, automatic_groups, pair_entries, prepare_pairs,
    sentence_ends, text_of,
)
import test_bilingual_native_gui as native

EN = 'Credit risk can rise. A hedge may reduce exposure. Liquidity is also important.'
ZH = '信用风险可能上升，对冲可以减少敞口。流动性同样重要。'
EN_COMBINED = 'Credit risk can rise, but a hedge may reduce exposure. Liquidity is also important.'
ZH_SEPARATE = '信用风险可能上升。对冲可以减少敞口。流动性同样重要。'
SOURCE = ('<html><body><div><p lang="zh">'+ZH+'</p><p lang="en">'+
          EN.replace('rise', '<b>rise</b>')+'</p></div>'
          '<div><p lang="zh">债券以99.5成交。</p>'
          '<p lang="en">The bond trades at 99.5.</p></div></body></html>')


class ApproximateGroupingTests(unittest.TestCase):
    def test_two_source_sentences_can_share_one_translation_group(self):
        pair = PairText('p', EN, ZH, True)
        groups = automatic_groups(pair)
        self.assertEqual(groups, [(sentence_ends(EN, 'en')[1], sentence_ends(ZH, 'zh')[0]), (len(EN), len(ZH))])

    def test_one_source_sentence_can_share_two_translation_sentences(self):
        pair = PairText('p', EN_COMBINED, ZH_SEPARATE, True)
        groups = automatic_groups(pair)
        self.assertEqual(groups, [(sentence_ends(EN_COMBINED, 'en')[0], sentence_ends(ZH_SEPARATE, 'zh')[1]), (len(EN_COMBINED), len(ZH_SEPARATE))])

    def test_unequal_groups_preserve_all_source_text_and_formatting(self):
        root = LH.fromstring(SOURCE)
        pair = pair_entries(root)[0][2]
        pairs, reviewed, rejected = prepare_pairs(root, auto_groups=True)
        self.assertEqual((reviewed, rejected), (0, 0))
        self.assertEqual(len(root.xpath('//*[@data-mr-group]')), 2)
        self.assertEqual(len(root.xpath('//b[text()="rise"]')), 1)
        for language in ('en', 'zh'):
            units = root.xpath(f'//*[@data-mr-para="{pair.key}"][@data-mr-lang="{language}"]')
            self.assertEqual(''.join(text_of(unit) for unit in units), getattr(pair, language))
        self.assertTrue(all(row.get('data-mr-group-kind') == 'auto' for row in root.xpath('//*[@data-mr-group]')))

    def test_unequal_groups_preserve_table_structure(self):
        root = LH.fromstring(f'<table><tr id="row"><td lang="en">{EN}</td><td lang="zh">{ZH}</td></tr></table>')
        prepare_pairs(root, auto_groups=True)
        self.assertEqual(len(root.xpath('//tr')), 2)
        self.assertFalse(root.xpath('//tr/*[not(self::td)]'))
        self.assertEqual(len(root.xpath('//*[@id="row"]')), 1)

    def test_reviewed_single_group_prevents_automatic_split(self):
        root = LH.fromstring(SOURCE); pair = pair_entries(root)[0][2]
        prepare_pairs(root, {pair.key: {'reviewed': True, 'ends': [[len(pair.en), len(pair.zh)]]}}, auto_groups=True)
        self.assertFalse(root.xpath('//*[@data-mr-auto-grouped]'))

    def test_severely_unbalanced_counts_do_not_force_groups(self):
        with self.assertRaises(AlignmentError):
            automatic_groups(PairText('p', 'First. Second. Third. Fourth. Fifth.', '第一。第二。', True))

    def test_single_translation_sentence_stays_whole(self):
        with self.assertRaises(AlignmentError):
            automatic_groups(PairText('p', 'First. Second.', '一个完整译句。', True))

    def test_indentation_does_not_change_groups(self):
        en = '\n  Credit risk can rise.  \n  A hedge may reduce exposure.  \n Liquidity is also important.'
        groups = automatic_groups(PairText('p', en, ZH, True))
        self.assertEqual(groups[0][0], sentence_ends(en, 'en')[1])

    def test_chapter_work_budget_leaves_remaining_source_pairs_intact(self):
        root = LH.fromstring('<html><body>' + SOURCE.split('<body>')[1].split('</body>')[0] * 2 + '</body></html>')
        pairs = [pair for _, _, pair in pair_entries(root)]
        # This fixture's unequal pair needs 4*3 cells. Only the first occurrence
        # may consume that budget, and both occurrences must retain all text.
        with patch('bilingual_alignment.MAX_ALIGNMENT_CELLS', 12):
            prepare_pairs(root, auto_groups=True)
        self.assertEqual(len(root.xpath('//*[@data-mr-auto-grouped]')), 1)
        for pair in pairs:
            for language in ('en', 'zh'):
                units = root.xpath(f'//*[@data-mr-para="{pair.key}"][@data-mr-lang="{language}"]')
                self.assertEqual(''.join(text_of(unit) for unit in units), getattr(pair, language))


@unittest.skipUnless(native.QT, '缺少 PySide6')
class NativeUnequalGroupCopyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        native.NativeCopyTests.setUpClass.__func__(cls)
    setUp = native.NativeCopyTests.setUp
    choose = native.NativeCopyTests.choose
    load_template = native.NativeCopyTests.load_template

    def test_english_copy_recombines_unequal_groups_without_chinese(self):
        self.load_template(SOURCE)
        self.choose('Credit', '99.5.')
        self.assertEqual(self.browser.copy_selection_text(), EN + '\n\nThe bond trades at 99.5.')
        self.browser.copy_for_language()
        self.assertEqual(self.app.clipboard().text(), EN + '\n\nThe bond trades at 99.5.')

    def test_backwards_partial_copy_keeps_exact_english_boundary(self):
        self.load_template(SOURCE)
        self.choose('Credit', '99.5.', reverse=True, partial=3)
        self.assertEqual(self.browser.copy_selection_text(), EN[3:] + '\n\nThe bond trades at 99.5.')

    def test_chinese_copy_recombines_unequal_groups(self):
        self.load_template(SOURCE)
        self.choose('信用', '99.5成交。')
        self.assertEqual(self.browser.copy_selection_text(), ZH + '\n\n债券以99.5成交。')
