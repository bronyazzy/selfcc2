"""New shell acceptance tests using actual Qt widgets and keyboard actions."""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

try:
    from PySide6.QtCore import Qt
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication, QToolBar
    from epub_core import StateStore
    from epub_reader import EnhancedReaderWindow
    QT = True
except (ImportError, OSError, SystemExit):
    QT = False

ROOT = Path(__file__).resolve().parents[1]


@unittest.skipUnless(QT, 'PySide6 unavailable')
class SlimShellTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setQuitOnLastWindowClosed(False)

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.state = StateStore(Path(self.temp.name) / 'state.json')
        with patch.dict(os.environ, {'MODU_COMPATIBLE_EPUB': '1'}):
            self.window = EnhancedReaderWindow(self.state)
        self.window.show()
        self.window.open_book(str(ROOT / 'parallel_demo.epub'))
        QTest.qWait(70)

    def tearDown(self):
        self.window.close()
        QTest.qWait(30)
        self.temp.cleanup()

    def test_new_user_has_one_toolbar_and_full_height_definition(self):
        w = self.window
        self.assertTrue(w.minimal_chrome)
        self.assertTrue(w.dictionary_dock.compact_active)
        self.assertFalse(w.sidebar.isVisible())
        self.assertFalse(w.reading_header.isVisible())
        self.assertFalse(w.menuBar().isVisible())
        visible = [bar for bar in w.findChildren(QToolBar) if bar.isVisible()]
        self.assertEqual(len(visible), 1)
        texts = [a.text() for a in visible[0].actions()]
        for text in ('双栏对照', '只看释义', '老板模式', '更多'):
            self.assertIn(text, texts)
        self.assertGreater(w.dictionary_dock.result_view.height(), w.height() * .8)

    def test_lookup_really_changes_definition_in_minimal_view(self):
        self.window.lookup_text('HIBOR')
        self.assertIn('香港银行同业拆息', self.window.dictionary_dock.result_view.toPlainText())
        self.assertTrue(self.window.dictionary_dock.compact_active)

    def test_search_shortcut_exposes_hidden_search_bar(self):
        self.window.browser.setFocus()
        QTest.keyClick(self.window.browser, Qt.Key.Key_F, Qt.KeyboardModifier.ControlModifier)
        QTest.qWait(30)
        self.assertTrue(self.window.reading_header.isVisible())
        self.assertTrue(self.window.search_edit.hasFocus())

    def test_boss_roundtrip_preserves_compact_shell(self):
        self.window.browser.setFocus()
        QTest.keyClick(self.window.browser, Qt.Key.Key_F9)
        QTest.qWait(30)
        self.assertTrue(self.window.boss_active)
        self.assertTrue(all(not w.isVisible() for w in self.window._chrome_widgets()))
        self.assertFalse(self.window.isFullScreen())
        QTest.keyClick(self.window.browser, Qt.Key.Key_Escape)
        QTest.qWait(30)
        self.assertFalse(self.window.boss_active)
        self.assertFalse(self.window.menuBar().isVisible())
        self.assertTrue(self.window.findChild(QToolBar, 'readerToolbar').isVisible())

    def test_switch_to_pdf_in_boss_mode_does_not_reveal_toolbars(self):
        self.window.set_boss_mode(True)
        self.assertTrue(self.window.open_book(str(ROOT / 'pdf_demo.pdf')))
        self.assertTrue(all(not w.isVisible() for w in self.window._chrome_widgets()))
        self.window.set_boss_mode(False)
        self.assertFalse(self.window.pdf_toolbar.isVisible())
        self.assertFalse(self.window.layout_toolbar.isVisible())
        self.assertFalse(self.window.parallel_action.isEnabled())
        self.window.toggle_pdf_controls(True)
        self.assertTrue(self.window.pdf_toolbar.isVisible())

    def test_compatible_launcher_f6_stays_native_after_settings_change(self):
        self.window.set_layout(english_percent=60)
        self.window.parallel_action.trigger()
        self.assertEqual(self.window.layout_settings.mode, 'compatible')
        self.assertTrue(self.window.parallel_action.isChecked())

    def test_full_controls_and_settings_remain_accessible(self):
        self.window.set_minimal_chrome(False)
        self.assertTrue(self.window.menuBar().isVisible())
        self.assertTrue(self.window.reading_header.isVisible())
        self.assertTrue(self.window.layout_toolbar.isVisible())
        self.window.set_minimal_chrome(True)
        self.window.toggle_layout_controls(True)
        self.assertTrue(self.window.layout_toolbar.isVisible())
        menus = [a.menu() for a in self.window.more_menu.actions() if a.menu()]
        dictionary_menu = next(m for m in menus if m.title() == '词典与词库')
        self.assertIn('导入 MDX / MDD…', [a.text() for a in dictionary_menu.actions()])

    def test_visibility_preferences_survive_boss_mode_save(self):
        self.window.toggle_sidebar(True)
        self.window.save_state()
        self.window.set_boss_mode(True)
        self.window.save_state()
        prefs = StateStore(Path(self.temp.name) / 'state.json').data['preferences']
        self.assertIs(prefs['sidebar_visible'], True)
        self.assertIs(prefs['minimal_chrome'], True)
        self.assertIs(prefs['dictionary_compact'], True)

    def test_existing_layout_font_and_expanded_dictionary_preferences_preserved(self):
        other = StateStore(Path(self.temp.name) / 'other' / 'state.json')
        other.data['preferences'].update({'epub_layout': {'mode': 'publisher'},
                                         'font_size': 20, 'dictionary_compact': False,
                                         'minimal_chrome': False})
        with patch.dict(os.environ, {'MODU_COMPATIBLE_EPUB': '1'}):
            w = EnhancedReaderWindow(other)
        try:
            self.assertEqual(w.layout_settings.mode, 'publisher')
            self.assertEqual(w.font_size, 20)
            self.assertFalse(w.dictionary_dock.compact_active)
            self.assertFalse(w.minimal_chrome)
        finally:
            w.close()


if __name__ == '__main__':
    unittest.main()
