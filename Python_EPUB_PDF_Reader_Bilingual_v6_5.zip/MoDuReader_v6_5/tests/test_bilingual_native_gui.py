"""Native Qt6 tests. Explicitly skipped without PySide6, never substituted."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from pathlib import Path
import tempfile
import unittest
from compatible_layout import compatible_chapter
from epub_core import EpubBook
from test_bilingual_browser import make_book
from test_bilingual_core import BLOCK_HTML, TABLE_HTML, EXPECTED_EN
try:
    from PySide6.QtWidgets import QApplication
    from PySide6.QtGui import QTextDocument,QTextCursor,QFont
    from PySide6.QtCore import Qt
    from epub_reader import BookBrowser
    from bilingual_native import install_metadata
    QT=True
except (ImportError,SystemExit):QT=False

@unittest.skipUnless(QT,'缺少 PySide6，未执行原生选区/剪贴板测试')
class NativeCopyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.path=Path(self.temp.name)/'test.epub';make_book(self.path)
        self.book=EpubBook(self.path);self.addCleanup(self.book.close)
        self.browser=BookBrowser();self.browser.resize(1100,700)
        self.addCleanup(self.browser.deleteLater)
        self.content=compatible_chapter(self.book,'OPS/first.xhtml',copy_markers=True)
        self.browser.copy_specs=self.content.copy_units
        self.doc=QTextDocument(self.browser);self.doc.setHtml(self.content.html)
        self.browser.attach_copy_metadata(self.doc);self.browser.setDocument(self.doc)
        self.browser.show();self.app.processEvents()
    def choose(self,start='Risk',end='NAV.',reverse=False,partial=0):
        a=self.doc.find(start).selectionStart()+partial;b=self.doc.find(end).selectionEnd()
        c=QTextCursor(self.doc)
        c.setPosition(b if reverse else a);c.setPosition(a if reverse else b,QTextCursor.MoveMode.KeepAnchor)
        self.browser.setTextCursor(c)
        self.browser._copy_mouse_range=(b,a) if reverse else (a,b)
        self.browser._update_copy_highlight()
    def test_markers_removed_before_display(self):self.assertNotIn('MRCP_',self.doc.toPlainText())
    def test_native_metadata_exists(self):self.assertTrue(self.browser.copy_spans)
    def test_two_paragraph_copy_english_only(self):
        self.choose();self.assertEqual(self.browser.copy_selection_text(),'Risk is not always loss. A hedge can reduce exposure.\n\nA second paragraph has 3.5% and NAV.')
    def test_reverse_same_result(self):
        self.choose();a=self.browser.copy_selection_text();self.choose(reverse=True);self.assertEqual(a,self.browser.copy_selection_text())
    def test_partial_start_preserved(self):
        self.choose(partial=2);self.assertTrue(self.browser.copy_selection_text().startswith('sk is'))
    def test_chinese_only(self):
        self.choose('风险','第二段保留3.5%和NAV。');text=self.browser.copy_selection_text();self.assertIn('第二段',text);self.assertNotIn('Risk',text)
    def test_explicit_chinese_filters_same_range(self):
        self.choose();self.assertEqual(self.browser.copy_selection_text('zh'),'风险并不总是损失。对冲可以降低敞口。')
    def test_clipboard_actual_text(self):
        self.choose();self.browser.copy_for_language();self.assertEqual(self.app.clipboard().text(),self.browser.copy_selection_text())
    def test_empty_selection_does_not_replace_clipboard(self):
        self.app.clipboard().setText('keep');self.browser.copy_for_language();self.assertEqual(self.app.clipboard().text(),'keep')
    def test_mime_data_contains_only_filtered_plaintext(self):
        self.choose();data=self.browser.createMimeDataFromSelection();self.assertNotIn('风险',data.text());self.assertFalse(data.hasHtml())
    def test_disabling_lock_restores_full_copy(self):
        self.choose();self.browser.copy_lock=False;self.assertIn('风险',self.browser.copy_selection_text())
    def test_reflow_preserves_copy_ranges(self):
        self.choose();text=self.browser.copy_selection_text();self.doc.setTextWidth(600);self.app.processEvents();self.assertEqual(text,self.browser.copy_selection_text())
    def test_selection_highlight_only_language_fragments(self):
        self.choose();self.assertTrue(self.browser.extraSelections())
        self.assertTrue(all('风险' not in s.cursor.selectedText() for s in self.browser.extraSelections()))
    def test_plain_document_resets_language_metadata(self):
        self.browser.setHtml('<p>Normal text</p>');self.browser.selectAll();self.assertFalse(self.browser.copy_spans);self.assertEqual(self.browser.copy_selection_text(),'Normal text')
    def test_broken_mapping_does_not_blank_document(self):
        self.browser.copy_specs=({'start':'missing','end':'also_missing','lang':'en','para':'p'},)
        self.browser.attach_copy_metadata(self.doc)
        self.assertIn('Risk',self.doc.toPlainText());self.assertTrue(self.browser.copy_mapping_error)
    def test_editor_preserves_nonbreaking_spaces(self):
        from PySide6.QtWidgets import QPlainTextEdit
        edit=QPlainTextEdit();edit.setPlainText('A\u00a0B\nC')
        self.assertEqual(edit.document().toRawText().replace('\u2029','\n'),'A\u00a0B\nC');edit.deleteLater()
    def test_inline_bold_not_lost(self):
        self.choose('not','loss.');self.assertEqual(self.browser.copy_selection_text(),'not always loss.')

    def load_template(self,source,auto=True):
        path=Path(self.temp.name)/'template.epub';make_book(path,source)
        book=EpubBook(path);self.addCleanup(book.close)
        content=compatible_chapter(book,'OPS/first.xhtml',copy_markers=True,auto_groups=auto)
        doc=QTextDocument(self.browser);doc.setHtml(content.html)
        self.browser.copy_specs=content.copy_units
        self.browser.attach_copy_metadata(doc);self.browser.setDocument(doc)
        self.doc=doc;self.app.processEvents()

    def test_cfa_block_auto_groups_copy_original_continuous_paragraphs(self):
        self.load_template(BLOCK_HTML)
        self.choose('Credit','4%.')
        self.assertEqual(self.browser.copy_selection_text(),EXPECTED_EN)

    def test_cfa_table_auto_groups_copy_original_continuous_paragraphs(self):
        self.load_template(TABLE_HTML)
        self.choose('Credit','4%.')
        self.assertEqual(self.browser.copy_selection_text(),EXPECTED_EN)
        self.browser.copy_for_language()
        self.assertEqual(self.app.clipboard().text(),EXPECTED_EN)

    def test_cfa_table_reverse_and_partial_copy(self):
        self.load_template(TABLE_HTML)
        self.choose('Credit','4%.',reverse=True,partial=3)
        self.assertEqual(self.browser.copy_selection_text(),EXPECTED_EN[3:])

    def test_cfa_table_without_auto_preserves_both_paragraphs(self):
        self.load_template(TABLE_HTML,False)
        self.choose('Credit','4%.')
        self.assertEqual(self.browser.copy_selection_text(),EXPECTED_EN)

    def test_cfa_table_keyboard_complex_selection_keeps_last_cell(self):
        self.load_template(TABLE_HTML)
        self.choose('Credit','4%.')
        self.browser._copy_mouse_range=None
        self.assertTrue(self.browser.textCursor().hasComplexSelection())
        self.assertEqual(self.browser.copy_selection_text('en'),EXPECTED_EN)
        self.assertEqual(self.browser.copy_selection_text(),EXPECTED_EN)
