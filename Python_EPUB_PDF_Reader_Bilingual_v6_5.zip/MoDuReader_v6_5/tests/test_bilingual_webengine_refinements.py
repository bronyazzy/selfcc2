"""Exercise refined copying/alignment through the actual Qt EPUB scheme."""
from pathlib import Path
import tempfile
import unittest
import test_publisher_gui as publication
from test_bilingual_browser import make_book
from test_alignment_refinements import SOURCE, EN, ZH


@unittest.skipUnless(publication.QT, '缺少 Qt / QtWebEngine')
class BilingualWebEngineRefinementTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        publication.PublicationGuiTests.setUpClass.__func__(cls)
    tearDown = publication.PublicationGuiTests.tearDown
    wait_ready = publication.PublicationGuiTests.wait_ready
    js = publication.PublicationGuiTests.js

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.file = Path(self.temp.name) / 'state.json'
        book = Path(self.temp.name) / 'unequal.epub'; make_book(book, SOURCE)
        state = publication.StateStore(self.file)
        state.data['preferences']['epub_layout'] = {'mode': 'parallel', 'english_percent': 55, 'line_height': 1.8}
        state.data['preferences']['auto_sentence_groups'] = True
        self.window = publication.EnhancedReaderWindow(state)
        self.window.show()
        self.assertTrue(self.window.open_book(str(book)))
        self.wait_ready(); self.view = self.window.publication_view

    def choose_boundary(self, reverse=False):
        return self.js('''(()=>{
          const units=[...document.querySelectorAll('[data-mr-lang="en"]')];
          const first=units[0],last=units[units.length-1];
          const index=n=>[...n.parentNode.childNodes].indexOf(n);
          const a=[first.parentNode,index(first)],b=[last.parentNode,index(last)+1];
          getSelection().setBaseAndExtent(...(%s?b:a),...(%s?a:b));
          return window.__modu.copyText();
        })()''' % (str(reverse).lower(), str(reverse).lower()))

    def test_boundary_selection_uses_english_not_old_chinese_pointer(self):
        self.js('''(()=>{
          const z=document.querySelector('[data-mr-lang="zh"]');
          z.dispatchEvent(new PointerEvent('pointerdown',{button:0,bubbles:true}));
          z.dispatchEvent(new PointerEvent('pointerup',{button:0,bubbles:true}));
        })()''')
        result = self.choose_boundary()
        self.assertEqual(result['language'], 'en')
        self.assertEqual(result['text'], EN + '\n\nThe bond trades at 99.5.')

    def test_reverse_boundary_selection_keeps_all_english(self):
        result = self.choose_boundary(True)
        self.assertEqual(result['language'], 'en')
        self.assertEqual(result['text'], EN + '\n\nThe bond trades at 99.5.')

    def test_unmarked_prose_does_not_inherit_earlier_pointer_language(self):
        result = self.js('''(()=>{
          const e=document.querySelector('[data-mr-lang="en"]');
          e.dispatchEvent(new PointerEvent('pointerdown',{button:0,bubbles:true}));
          e.dispatchEvent(new PointerEvent('pointerup',{button:0,bubbles:true}));
          const p=document.createElement('p');p.textContent='Unmarked text with 中文 quotation.';document.body.append(p);
          const r=document.createRange();r.selectNodeContents(p);
          getSelection().removeAllRanges();getSelection().addRange(r);
          return window.__modu.copyText();
        })()''')
        self.assertEqual(result['language'], 'both')
        self.assertEqual(result['text'], 'Unmarked text with 中文 quotation.')

    def test_real_ctrl_c_after_unequal_grouping_in_boss_mode(self):
        from PySide6.QtCore import Qt
        self.window.set_boss_mode(True)
        publication.QTest.qWait(100)
        self.choose_boundary(True)
        self.app.clipboard().setText('sentinel')
        target = self.view.focusProxy() or self.view
        target.setFocus()
        publication.QTest.keyClick(target, Qt.Key.Key_C, Qt.KeyboardModifier.ControlModifier)
        expected = EN + '\n\nThe bond trades at 99.5.'
        for _ in range(80):
            if self.app.clipboard().text() == expected:
                break
            publication.QTest.qWait(20)
        self.assertEqual(self.app.clipboard().text(), expected)
        self.assertTrue(self.window.boss_active)

    def test_group_tops_match_after_resize_without_changing_source_text(self):
        for width in (1200, 760):
            self.window.resize(width, 800); publication.QTest.qWait(100)
            rows = self.js('''[...document.querySelectorAll('[data-mr-pair]')].map(n=>{
              const e=n.querySelector('[data-mr-lang="en"]').getBoundingClientRect();
              const z=n.querySelector('[data-mr-lang="zh"]').getBoundingClientRect();
              return {ey:e.y,zy:z.y};
            })''')
            self.assertEqual(len(rows), 3)
            for row in rows:
                self.assertAlmostEqual(row['ey'], row['zy'], delta=.5)
            self.assertEqual(self.choose_boundary()['text'], EN + '\n\nThe bond trades at 99.5.')

    def test_chinese_first_columns_have_interior_gap_and_divider(self):
        rows = self.js('''[...document.querySelectorAll('[data-mr-pair]')].map(n=>
          [...n.children].map(c=>{const s=getComputedStyle(c),r=c.getBoundingClientRect();
            return {language:c.dataset.mrLang,x:r.x,width:r.width,
              left:parseFloat(s.paddingLeft),right:parseFloat(s.paddingRight),
              borderLeft:parseFloat(s.borderLeftWidth),borderRight:parseFloat(s.borderRightWidth)};
          }))''')
        self.assertEqual(len(rows), 3)
        for first, second in rows:
            self.assertEqual((first['language'], second['language']), ('zh', 'en'))
            self.assertEqual((first['left'], first['borderLeft'], first['borderRight']), (0, 0, 0))
            self.assertGreater(first['right'], 0)
            self.assertGreater(second['left'], 0)
            self.assertEqual((second['right'], second['borderLeft'], second['borderRight']), (0, 1, 0))
            self.assertAlmostEqual(first['x'] + first['width'], second['x'], delta=.5)
            self.assertGreater(second['width'], first['width'])  # English keeps 55% width.

    def test_stack_and_single_language_remove_column_dividers(self):
        for mode in ('stack', 'en', 'zh'):
            self.window.set_layout(mode=mode); publication.QTest.qWait(70)
            borders = self.js('''[...document.querySelectorAll('[data-mr-pair] > [data-mr-lang]')].map(c=>{
              const s=getComputedStyle(c);return [parseFloat(s.paddingLeft),parseFloat(s.paddingRight),
                parseFloat(s.borderLeftWidth),parseFloat(s.borderRightWidth)];
            })''')
            self.assertTrue(borders)
            self.assertTrue(all(value == [0, 0, 0, 0] for value in borders), (mode, borders))
