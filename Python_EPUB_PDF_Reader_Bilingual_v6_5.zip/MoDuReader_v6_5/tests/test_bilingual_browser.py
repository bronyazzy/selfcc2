"""Real Chromium calls production JS. Not Qt transport or OS clipboard tests."""
from pathlib import Path
import os
import shutil
import tempfile
import unittest
import zipfile
from lxml import html as LH
from epub_core import EpubBook
from publisher_core import PublisherResources,LayoutSettings,appearance_payload
from bilingual_alignment import AlignmentStore,pair_entries,text_of,prepare_pairs
from browser_harness import load,ROOT,GEOMETRY
from test_bilingual_core import HTML,fixture,BLOCK_HTML,TABLE_HTML,EXPECTED_EN
try:
    from playwright.sync_api import sync_playwright
    AVAILABLE=True
except ImportError:AVAILABLE=False


def make_book(path, source=HTML):
    with zipfile.ZipFile(path,'w') as z:
        z.writestr('mimetype','application/epub+zip')
        z.writestr('META-INF/container.xml','<container><rootfiles><rootfile full-path="OPS/book.opf"/></rootfiles></container>')
        z.writestr('OPS/book.opf','<package><metadata><title>Bilingual test</title></metadata><manifest><item id="a" href="first.xhtml" media-type="application/xhtml+xml"/></manifest><spine><itemref idref="a"/></spine></package>')
        z.writestr('OPS/first.xhtml',source)

@unittest.skipUnless(AVAILABLE,'没有 Playwright')
class BilingualBrowserTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pw=sync_playwright().start()
        executable=os.environ.get('MODU_CHROMIUM') or shutil.which('chromium') or shutil.which('chromium-browser')
        try:cls.browser=cls.pw.chromium.launch(**({'executable_path':executable} if executable else {}),headless=True,args=['--no-sandbox'] if hasattr(os,'geteuid') and os.geteuid()==0 else [])
        except Exception as exc:cls.pw.stop();raise unittest.SkipTest(str(exc)[:200])
    @classmethod
    def tearDownClass(cls):cls.browser.close();cls.pw.stop()
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.path=Path(self.temp.name)/'test.epub';make_book(self.path)
        self.book=EpubBook(self.path);self.addCleanup(self.book.close)
        self.store=AlignmentStore(Path(self.temp.name),self.book.book_id)
        self.resource=PublisherResources(self.book,self.store)
        self.page=self.browser.new_page(viewport={'width':1200,'height':800});self.addCleanup(self.page.close)
        self.page.route('**/*',lambda r:r.abort())
        self.settings=appearance_payload(LayoutSettings(mode='parallel',english_percent=55,line_height=1.8),'#ffffff',18)
        load(self.page,self.resource,'OPS/first.xhtml',self.settings)
    def select(self,lang='en',reverse=False,start=0,end=None):
        return self.page.evaluate('''([lang,rev,start,end])=>{
          const units=[...document.querySelectorAll('[data-mr-lang="'+lang+'"]')];
          const first=units[0],last=units[units.length-1];
          const texts=n=>{const w=document.createTreeWalker(n,NodeFilter.SHOW_TEXT);let t=[],x;while(x=w.nextNode())t.push(x);return t;};
          const a=texts(first)[0],ts=texts(last),b=ts[ts.length-1];
          end=end===null?b.length:end;
          const s=getSelection();s.removeAllRanges();
          if(rev)s.setBaseAndExtent(b,end,a,start);else s.setBaseAndExtent(a,start,b,end);
          return window.__modu.copyText('auto');
        }''',[lang,reverse,start,end])
    def expected(self,lang):
        return self.page.eval_on_selector_all('[data-mr-lang="'+lang+'"]','nodes=>nodes.map(x=>x.textContent.trim()).join("\\n\\n")')
    def test_two_english_paragraphs_no_chinese(self):
        out=self.select();self.assertEqual(out['text'],self.expected('en'));self.assertNotIn('第二',out['text'])
    def test_reverse_selection_same_text(self):
        self.assertEqual(self.select(reverse=True)['text'],self.expected('en'))
    def test_chinese_origin(self):
        self.assertEqual(self.select('zh')['text'],self.expected('zh'))
    def test_partial_ends_not_expanded_to_whole_paragraphs(self):
        expected=self.expected('en')[2:-3]
        lastlen=self.page.locator('[data-mr-lang="en"]').last.evaluate('x=>x.lastChild.length')
        self.assertEqual(self.select(start=2,end=lastlen-3)['text'],expected)
    def test_explicit_other_language_clips_to_original_range(self):
        self.select();out=self.page.evaluate('window.__modu.copyText("zh")')
        # English endpoint is before the second Chinese paragraph in DOM.
        self.assertEqual(out['text'],self.page.locator('[data-mr-lang="zh"]').first.text_content())
    def test_both_mode_does_not_obey_hidden_selection_style(self):
        self.select();self.page.wait_for_timeout(20)
        out=self.page.evaluate('window.__modu.copyText("both")')
        self.assertIn('风险',out['text']);self.assertIn('A second',out['text'])
    def test_lock_can_be_disabled(self):
        self.settings['copy_lock']=False;self.page.evaluate('s=>window.__modu.settings(s,false)',self.settings)
        self.assertIn('风险',self.select()['text'])
    def test_lookup_uses_language_filter(self):
        self.select();out=self.page.evaluate('window.__modu.selection()');self.assertNotIn('风险',out['text'])
    def test_no_selection_empty_result(self):
        self.page.evaluate('getSelection().removeAllRanges()');self.assertEqual(self.page.evaluate('window.__modu.copyText().text'),'')
    def test_script_does_not_lose_non_ascii_inside_english(self):
        self.page.locator('[data-mr-lang="en"]').first.evaluate('(n)=>n.appendChild(document.createTextNode(" 中文引用 NAV 3.5%"))')
        out=self.select();self.assertIn('中文引用 NAV 3.5%',out['text'])
    def grouped(self):
        root=LH.fromstring(self.resource.chapter('OPS/first.xhtml'));p=pair_entries(root)[0][2]
        ends=[(p.en.index(' A hedge')+1,p.zh.index('。')+1),(len(p.en),len(p.zh))]
        self.store.save_pair('OPS/first.xhtml',p,ends)
        self.resource=PublisherResources(self.book,self.store)
        load(self.page,self.resource,'OPS/first.xhtml',self.settings)
        return p
    def test_reviewed_groups_have_same_tops(self):
        self.grouped();geometry=self.page.evaluate(GEOMETRY);self.assertEqual(len(geometry),3)
        for row in geometry:self.assertAlmostEqual(row['ey'],row['zy'],delta=.5)
        self.assertGreater(geometry[1]['ey'],geometry[0]['ey'])
    def test_reviewed_groups_recombine_original_paragraphs(self):
        p=self.grouped();out=self.select()
        self.assertEqual(out['text'],p.en+'\n\nA second paragraph has 3.5% and NAV.')
    def test_copy_inside_group_preserves_partial_boundary(self):
        self.grouped();out=self.select(start=2)
        self.assertTrue(out['text'].startswith('sk is not'))
    def test_narrow_group_top_alignment(self):
        self.grouped();self.page.set_viewport_size({'width':600,'height':800});self.page.wait_for_timeout(30)
        for row in self.page.evaluate(GEOMETRY):self.assertAlmostEqual(row['ey'],row['zy'],delta=.5)
    def test_grouped_english_and_chinese_views_restore(self):
        self.grouped()
        for mode in ('en','zh','parallel'):
            self.settings['mode']=mode;self.page.evaluate('s=>window.__modu.settings(s,false)',self.settings)
            rows=self.page.evaluate(GEOMETRY)
            if mode=='en':self.assertTrue(all(x['zw']==0 for x in rows))
            if mode=='zh':self.assertTrue(all(x['ew']==0 for x in rows))
    def test_new_pointer_changes_language_after_previous_selection(self):
        self.select('en');self.page.wait_for_timeout(20)
        z=self.page.locator('[data-mr-lang="zh"]').first
        z.dispatch_event('pointerdown',{'button':0});self.assertEqual(self.page.evaluate('document.documentElement.dataset.mrCopyLanguage'),'zh')
        z.dispatch_event('pointerup',{'button':0})
    def test_large_copy_not_word_lookup_limit(self):
        text='A long English paragraph. '*2000
        self.page.locator('[data-mr-lang="en"]').first.evaluate('(n,t)=>n.textContent=t',text)
        out=self.select();self.assertGreater(len(out['text']),20000);self.assertIn(text.strip(),out['text'])
    def test_real_mouse_drag_stays_in_language(self):
        positions=self.page.evaluate("""()=>{
          const ns=[...document.querySelectorAll('[data-mr-lang="en"]')];
          const a=document.createRange();a.setStart(ns[0].firstChild,0);a.setEnd(ns[0].firstChild,1);
          const b=document.createRange();b.setStart(ns[1].lastChild,ns[1].lastChild.length-1);b.setEnd(ns[1].lastChild,ns[1].lastChild.length);
          const x=a.getBoundingClientRect(),y=b.getBoundingClientRect();return [x.left+1,x.top+x.height/2,y.right,y.top+y.height/2];
        }""")
        self.page.mouse.move(*positions[:2]);self.page.mouse.down()
        self.page.mouse.move(*positions[2:],steps=10);self.page.mouse.up()
        out=self.page.evaluate('window.__modu.copyText()')
        self.assertIn('A second paragraph',out['text']);self.assertNotIn('风险',out['text'])
    def test_equal_heading_setting_keeps_grouping(self):
        self.grouped();self.settings['uniform_titles']=True;self.settings['boss_mode']=True
        self.page.evaluate('s=>window.__modu.settings(s,true)',self.settings)
        self.assertEqual(len(self.page.evaluate(GEOMETRY)),3);self.assertNotIn('风险',self.select()['text'])

    def load_template(self,source):
        path=Path(self.temp.name)/'template.epub';make_book(path,source)
        book=EpubBook(path);self.addCleanup(book.close)
        self.resource=PublisherResources(book,auto_groups=True)
        load(self.page,self.resource,'OPS/first.xhtml',self.settings)

    def test_cfa_block_automatic_groups_copy_source_paragraphs(self):
        self.load_template(BLOCK_HTML)
        self.assertEqual(self.select()['text'],EXPECTED_EN)
        self.assertEqual(self.select(reverse=True)['text'],EXPECTED_EN)
        self.assertEqual(self.select(start=3)['text'],EXPECTED_EN[3:])

    def test_cfa_table_automatic_groups_remain_rows_and_copy_source_paragraphs(self):
        self.load_template(TABLE_HTML)
        self.assertEqual(self.page.locator('table').count(),1)
        self.assertEqual(self.page.locator('table tr').count(),4)
        self.assertEqual(self.select()['text'],EXPECTED_EN)
        self.assertEqual(self.select(reverse=True)['text'],EXPECTED_EN)

    def test_cfa_table_group_geometry_reflows_without_cross_column_overlap(self):
        self.load_template(TABLE_HTML)
        for width in (1200,680):
            self.page.set_viewport_size({'width':width,'height':800})
            self.page.wait_for_timeout(30)
            rows=self.page.evaluate(GEOMETRY)
            self.assertEqual(len(rows),4)
            for row in rows:
                self.assertAlmostEqual(row['ey'],row['zy'],delta=.5)
                self.assertLessEqual(row['ex']+row['ew'],row['zx']+.5)
            self.assertTrue(all(rows[i+1]['ey']>=rows[i]['ey']+rows[i]['eh']-.5 for i in range(len(rows)-1)))

    def test_cfa_table_switching_single_language_and_parallel_preserves_text(self):
        self.load_template(TABLE_HTML)
        for mode in ('en','zh','stack','parallel'):
            self.settings['mode']=mode;self.page.evaluate('s=>window.__modu.settings(s,false)',self.settings)
            rows=self.page.evaluate(GEOMETRY)
            if mode=='en':
                self.assertTrue(all(x['zw']==0 for x in rows))
                self.assertEqual(self.select()['text'],EXPECTED_EN)
            elif mode=='zh':self.assertTrue(all(x['ew']==0 for x in rows))
            elif mode=='parallel':
                self.assertTrue(all(abs(x['ey']-x['zy'])<.5 for x in rows))
                self.assertEqual(self.select()['text'],EXPECTED_EN)

    def test_automatic_block_groups_work_in_publisher_mode(self):
        self.settings['mode']='publisher'
        self.load_template(BLOCK_HTML)
        rows=self.page.evaluate(GEOMETRY)
        self.assertEqual(len(rows),4)
        self.assertTrue(all(abs(x['ey']-x['zy'])<.5 for x in rows))
        self.assertEqual(self.select()['text'],EXPECTED_EN)
