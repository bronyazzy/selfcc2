"""Read-only bilingual metadata and lossless sentence-group presentation.

Reviewed groups live locally. Optional automatic groups are a punctuation-only
approximation within an existing bilingual pair, never a reviewed translation.
Offsets are Unicode codepoints, not screen lines; source EPUBs stay unchanged.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import re
import tempfile
from lxml import etree, html as LH

MAX_SIDECAR = 8 * 1024 * 1024
MAX_GROUPS = 128
MAX_ALIGNMENT_CELLS = 250_000
INLINE = {'span','a','b','strong','i','em','u','s','sub','sup','code','small',
          'abbr','cite','q','mark','del','ins','time','bdi','bdo'}
DELIMITER = '\n⟦对齐分组⟧\n'


class AlignmentError(ValueError):
    pass


@dataclass
class AlignmentWorkBudget:
    """Bound automatic dynamic-programming work for one chapter render."""
    remaining_cells: int = MAX_ALIGNMENT_CELLS

    def consume(self, count):
        if count > self.remaining_cells:
            raise AlignmentError('本章自动句组计算已达到上限；余下段落保持完整。')
        self.remaining_cells -= count


def text_of(node) -> str:
    return ''.join(node.itertext())


def tag_of(node) -> str:
    return str(node.tag).rsplit('}', 1)[-1].lower()


def inline_container(unit):
    """Return the one prose run that can be sliced without merging paragraphs.

    Existing books use span/span, div > p/p and tr > td > p.  The language
    wrapper itself is allowed to be a block, but multi-paragraph cells, hard
    breaks, pictures, tables and formulas are deliberately left intact.
    """
    if tag_of(unit) not in INLINE | {'p', 'div', 'td', 'th'}:
        return None
    content = unit
    while True:
        children = list(content)
        if (len(children) == 1 and tag_of(children[0]) in {'p', 'div'}
                and not (content.text or '').strip()
                and not (children[0].tail or '').strip()):
            content = children[0]
        else:
            break
    if all(tag_of(n) in INLINE for n in content.iterdescendants()):
        return content
    return None


def editable_pair(node, units):
    """Accept explicit single-prose pairs without treating data as sentences."""
    chain = (node, *node.iterancestors())
    if any(tag_of(a) in {'pre', 'code', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'} for a in chain):
        return False
    blocked_classes = {'heading', 'title', 'subtitle', 'formula', 'equation', 'image', 'figure', 'caption'}
    if any(set(a.get('class', '').lower().split()) & blocked_classes for a in chain[:2]):
        return False
    # Only the actual two-cell language row may be grouped inside a table.
    if any(tag_of(a) == 'table' for a in node.iterancestors()) and tag_of(node) != 'tr':
        return False
    if tag_of(node) == 'tr' and any(tag_of(u) != 'td' for u in units.values()):
        return False  # bilingual table headings stay headings
    if not any(tag_of(a) in {'p', 'blockquote', 'li', 'div', 'tr'} for a in chain):
        return False
    return all(inline_container(u) is not None for u in units.values())


@dataclass(frozen=True)
class PairText:
    key: str
    en: str
    zh: str
    editable: bool
    reason: str = ''


def pair_entries(root):
    # Runtime import avoids making the existing publication sanitizer depend on
    # this module while defining its allowlist.
    from publisher_core import has_pair, language
    entries = []; occurrences = {}
    for node in root.iter():
        if not isinstance(node.tag, str) or not has_pair(node):
            continue
        if any(tag_of(a) in {'head','script','style','template','noscript'} for a in node.iterancestors()):
            continue
        units = {language(c): c for c in node}
        en, zh = text_of(units['en']), text_of(units['zh'])
        # Stable across rendering engines and width/font changes. Repeated text
        # is disambiguated by document order, never matched just by word count.
        digest = hashlib.sha256(json.dumps([en, zh], ensure_ascii=False).encode()).hexdigest()[:24]
        occurrence = occurrences.get(digest, 0); occurrences[digest] = occurrence + 1
        key = digest + f'{occurrence:08x}'
        safe = editable_pair(node, units)
        safe = safe and 0 < len(en) <= 60000 and 0 < len(zh) <= 60000
        pair = PairText(key, en, zh, safe, '' if safe else '含图像、表格、复杂块、标题或超长内容；保留原段，不自动拆分。')
        entries.append((node, units, pair))
    return entries


def validate_groups(pair: PairText, record) -> list[tuple[int, int]]:
    if not pair.editable or not isinstance(record, dict) or record.get('reviewed') is not True:
        raise AlignmentError('该段不支持拆组，或尚未确认核对。')
    groups = record.get('ends')
    if not isinstance(groups, list) or not 1 <= len(groups) <= MAX_GROUPS:
        raise AlignmentError('分组数量必须为 1–128。')
    previous = (0, 0)
    result = []
    for value in groups:
        if (not isinstance(value, (list, tuple)) or len(value) != 2
                or any(type(x) is not int for x in value)):
            raise AlignmentError('对齐位置必须是两个整数。')
        en, zh = value
        if not (previous[0] < en <= len(pair.en) and previous[1] < zh <= len(pair.zh)):
            raise AlignmentError('各组必须前后连续、两侧非空，且不超出原文。')
        if not pair.en[previous[0]:en].strip() or not pair.zh[previous[1]:zh].strip():
            raise AlignmentError('不能创建只有空白的对照组。')
        result.append((en, zh)); previous = en, zh
    if previous != (len(pair.en), len(pair.zh)):
        raise AlignmentError('分组必须完整覆盖两侧原文；不能删减或截断。')
    return result


def sentence_ends(text: str, language: str) -> list[int]:
    """Punctuation-only EDITOR DRAFT, never automatically applied as translation."""
    ends = []
    if language == 'zh':
        pattern = r'[。！？]+[”’」』）】]*\s*'
    else:
        pattern = r'[.!?]+["\u201d\u2019\)\]]*(?:\s+|$)'
    for match in re.finditer(pattern, text):
        if language == 'en' and text[match.start()] == '.':
            prefix = text[:match.start()]
            word = re.search(r'([\w.]+)$', prefix)
            token = word.group(1).lower() if word else ''
            # Dates, decimals, initials and common abbreviations are not cuts.
            if token in {'mr','mrs','ms','dr','prof','jr','sr','vs','etc','fig','figs','no','nos','st','inc','e.g','i.e','u.s','u.k'}:
                continue
            if re.fullmatch(r'[a-z](?:\.[a-z])*', token):
                continue
        end = match.end()
        if end > (ends[-1] if ends else 0): ends.append(end)
    if not ends or ends[-1] != len(text): ends.append(len(text))
    return ends


def draft_groups(pair: PairText):
    if not pair.editable: raise AlignmentError(pair.reason)
    en, zh = sentence_ends(pair.en, 'en'), sentence_ends(pair.zh, 'zh')
    if len(en) != len(zh) or not 1 < len(en) <= MAX_GROUPS:
        raise AlignmentError('两侧候选句数不同或只有一组。请手动插入分组符，允许一组包含多句；不会强行配对。')
    return list(zip(en, zh))  # caller MUST require explicit review before saving


def automatic_groups(pair: PairText, budget: AlignmentWorkBudget | None = None):
    """Approximate short sentence groups without assuming one-to-one translation.

    A translation may combine two source sentences, or split one into two.
    Align monotonic 1:1, 1:2 and 2:1 groups using their share of the paragraph's
    text length. This is a layout heuristic, never a semantic translation
    match. It runs only within a publisher's existing bilingual pair and never
    produces missing, overlapping or invented text. Reviewed offsets always
    take precedence in ``prepare_pairs``.

    Equal sentence counts retain the familiar punctuation-based split. Highly
    unbalanced or very large inputs remain a single untouched source pair.
    """
    if not pair.editable:
        raise AlignmentError(pair.reason)
    en, zh = sentence_ends(pair.en, 'en'), sentence_ends(pair.zh, 'zh')
    n, m = len(en), len(zh)
    if n == m:
        return draft_groups(pair)
    if min(n, m) < 2 or max(n, m) > MAX_GROUPS or max(n, m) > 2 * min(n, m):
        raise AlignmentError('两侧句数差距过大或可用句组过少；保留整段，可手动分组。')
    if budget is not None:
        budget.consume((n + 1) * (m + 1))

    # Use non-whitespace lengths so source indentation cannot move a boundary.
    def weights(text, ends):
        prefix = [0]; previous = 0
        for end in ends:
            prefix.append(prefix[-1] + max(1, len(re.sub(r'\s+', '', text[previous:end]))))
            previous = end
        return prefix
    ew, zw = weights(pair.en, en), weights(pair.zh, zh)
    et, zt = ew[-1], zw[-1]
    scores = {(0, 0): 0.0}; back = {}
    # A small merge penalty prefers short groups; a relative-length penalty
    # discourages pairing one short clause with a large unrelated block.
    for i in range(n + 1):
        for j in range(m + 1):
            previous = scores.get((i, j))
            if previous is None:
                continue
            for a, b in ((1, 1), (1, 2), (2, 1)):
                x, y = i + a, j + b
                if x > n or y > m:
                    continue
                efrac, zfrac = (ew[x] - ew[i]) / et, (zw[y] - zw[j]) / zt
                cost = abs(math.log(efrac / zfrac)) + .22 * (a + b - 2)
                cost += 1.5 * abs(ew[x] / et - zw[y] / zt)
                score = previous + cost
                if score < scores.get((x, y), math.inf):
                    scores[(x, y)] = score; back[(x, y)] = (i, j)
    position = (n, m); groups = []
    while position != (0, 0):
        if position not in back:
            raise AlignmentError('未找到连续句组；保留整段。')
        i, j = position; groups.append((en[i - 1], zh[j - 1])); position = back[position]
    groups.reverse()
    # Reuse the losslessness checks without persisting/claiming a review.
    return validate_groups(pair, {'reviewed': True, 'ends': groups})


def group_editor_text(text, ends):
    start = 0; parts = []
    for end in ends:
        parts.append(text[start:end]); start = end
    return DELIMITER.join(parts)


def parse_editor(pair, en_text, zh_text):
    en, zh = en_text.split(DELIMITER), zh_text.split(DELIMITER)
    if ''.join(en) != pair.en or ''.join(zh) != pair.zh:
        raise AlignmentError('正文被改动了。此编辑器只允许插入/删除分组符，不允许删改英文或译文；可点“恢复原段”。')
    if len(en) != len(zh): raise AlignmentError('两侧分组数不一致；可让一侧多句对应另一侧一句。')
    x = y = 0; ends = []
    for a, b in zip(en, zh):
        x += len(a); y += len(b); ends.append([x,y])
    return validate_groups(pair, {'reviewed': True, 'ends': ends})


def slice_inline(unit, start: int, end: int):
    """Clone an inline subtree's exact text slice, retaining inline markup/links.

    Never splits media or block structures (enforced before calling). IDs only
    appear on the slice containing the original element's starting position.
    """
    offset = 0
    def visit(node):
        nonlocal offset
        begin = offset
        clone = LH.Element(tag_of(node), dict(node.attrib))
        def take(text):
            nonlocal offset
            text = text or ''; a = offset; offset += len(text)
            return text[max(0, start-a):max(0, min(len(text), end-a))] if end > a and start < offset else ''
        clone.text = take(node.text)
        for child in node:
            child_clone = visit(child)
            tail = take(child.tail)
            if child_clone is not None:
                clone.append(child_clone); child_clone.tail = tail
            elif len(clone): clone[-1].tail = (clone[-1].tail or '') + tail
            else: clone.text = (clone.text or '') + tail
        if not (start <= begin < end):
            clone.attrib.pop('id', None); clone.attrib.pop('name', None)
        if not text_of(clone) and not (begin == offset and start <= begin < end and node.get('id')):
            return None
        return clone
    value = visit(unit)
    if value is None: value = LH.Element(tag_of(unit), dict(unit.attrib))
    value.tail = None
    if text_of(value) != text_of(unit)[start:end]:
        raise AlignmentError('内联结构拆分未通过原文一致性检查。')
    return value


def prepare_pairs(root, records=None, apply=True, auto_groups=False):
    """Mark source paragraphs; prefer reviewed groups over optional approximation.

    The returned applied count continues to mean reviewed records. Automatic
    source paragraphs are separately marked with data-mr-auto-grouped, so the
    UI cannot accidentally call them reviewed. No automatic result is saved.
    """
    from publisher_core import language
    records = records if isinstance(records, dict) else {}
    entries = pair_entries(root); applied = 0; rejected = 0
    budget = max(0,120000 - sum(1 for _ in root.iter()))
    alignment_budget = AlignmentWorkBudget(MAX_ALIGNMENT_CELLS)
    for node, units, pair in entries:
        node.set('data-mr-pair', '1')
        for lang, unit in units.items():
            unit.set('data-mr-lang', lang); unit.set('data-mr-para', pair.key)
            if pair.editable: unit.set('data-mr-copy-inline', '1')
        automatic = False
        if apply and pair.key in records:
            try: ends = validate_groups(pair, records[pair.key])
            except AlignmentError:
                rejected += 1; continue
        elif auto_groups:
            try: ends = automatic_groups(pair, alignment_budget)
            except AlignmentError: continue
            automatic = True
        else:
            continue
        if len(ends) <= 1: continue
        if any(child.get('data-mr-split') for child in node.iterdescendants()):
            rejected += 1; continue
        groups = []; start = (0,0)
        is_row = tag_of(node) == 'tr'
        group_tag = 'tr' if is_row else ('div' if any(tag_of(u) in {'p', 'div'} for u in units.values()) else 'span')
        language_order = tuple(language(child) for child in node)
        try:
            for index, end in enumerate(ends):
                attributes = dict(node.attrib) if is_row else {}
                attributes.update({'data-mr-pair':'1', 'data-mr-group':str(index),
                    'data-mr-group-kind':'auto' if automatic else 'reviewed'})
                attributes['class'] = (attributes.get('class', '') + (' mr-auto-group' if automatic else ' mr-reviewed-group')).strip()
                if is_row and index:
                    attributes.pop('id', None); attributes.pop('name', None)
                group = LH.Element(group_tag, attributes)
                # Preserve the source side order. Otherwise Chinese-first CFA
                # pages would alternate their columns only on grouped rows.
                for lang in language_order:
                    j = 0 if lang == 'en' else 1
                    unit = slice_inline(units[lang], start[j], end[j])
                    unit.set('data-mr-lang', lang); unit.set('data-mr-para',pair.key)
                    group.append(unit)
                groups.append(group); start = end
        except AlignmentError:
            rejected += 1; continue
        extra_nodes=sum(sum(1 for _ in g.iter()) for g in groups)
        if extra_nodes > budget:
            rejected += 1; continue
        budget -= extra_nodes
        # A source <tr> must remain rows in its original table. Wrapping it in a
        # span/div makes HTML parsers move the text outside the table.
        if is_row:
            parent = node.getparent()
            if parent is None:
                rejected += int(not automatic); continue
            index = parent.index(node)
            groups[-1].tail = node.tail
            parent.remove(node)
            for offset, group in enumerate(groups): parent.insert(index + offset, group)
            if automatic: groups[0].set('data-mr-auto-grouped', '1')
        else:
            # Retain outer IDs, paragraph and links. Mutation happens only after
            # every source-text slice has passed exact preservation checks.
            for child in list(node): node.remove(child)
            node.text = None
            node.attrib.pop('data-mr-pair',None)
            node.set('data-mr-split','1')
            if automatic: node.set('data-mr-auto-grouped', '1')
            for group in groups: node.append(group)
        applied += int(not automatic)
    return [p for _,_,p in entries], applied, rejected


class AlignmentStore:
    def __init__(self, directory: Path, book_id: str):
        if not re.fullmatch(r'[0-9a-f]{64}', book_id): raise AlignmentError('书籍标识无效。')
        self.path = Path(directory) / 'alignments' / (book_id + '.json')
        self.book_id = book_id
        self.warning = ''
        self.data = {'version':1,'book_id':book_id,'chapters':{}}
        if self.path.exists():
            try:
                if self.path.stat().st_size > MAX_SIDECAR: raise AlignmentError('对齐记录超过 8 MiB。')
                data = json.loads(self.path.read_text('utf-8'))
                if not isinstance(data,dict) or data.get('version') != 1 or data.get('book_id') != book_id or not isinstance(data.get('chapters'),dict):
                    raise AlignmentError('对齐记录格式无效。')
                if any(not isinstance(k,str) or not isinstance(v,dict) for k,v in data['chapters'].items()):
                    raise AlignmentError('对齐章节记录无效。')
                self.data = data
            except (OSError,ValueError,UnicodeError) as exc:
                self.warning = f'对齐记录未载入，原文件受保护：{exc}'

    def chapter(self, path):
        return self.data['chapters'].get(path, {})

    def save_pair(self, path: str, pair: PairText, ends):
        if self.warning: raise AlignmentError(self.warning)
        record = {'reviewed':True,'ends':[list(x) for x in ends]}
        validate_groups(pair, record)
        data = deepcopy(self.data)
        data['chapters'].setdefault(path,{})[pair.key] = record
        self._save(data)

    def remove_pair(self, path, key):
        if self.warning: raise AlignmentError(self.warning)
        data = deepcopy(self.data); data['chapters'].get(path,{}).pop(key,None)
        self._save(data)

    def _save(self,data):
        raw = json.dumps(data,ensure_ascii=False,indent=2).encode('utf-8')
        if len(raw) > MAX_SIDECAR: raise AlignmentError('对齐记录超过大小上限。')
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = None
        try:
            with tempfile.NamedTemporaryFile('wb',dir=self.path.parent,prefix='.alignment-',delete=False) as f:
                temp = Path(f.name);f.write(raw);f.flush();os.fsync(f.fileno())
            os.replace(temp,self.path); self.data = data
        finally:
            if temp is not None: temp.unlink(missing_ok=True)
