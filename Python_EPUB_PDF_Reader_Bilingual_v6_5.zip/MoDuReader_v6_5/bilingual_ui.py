"""Bilingual tools shared by WebEngine, compatible/boss mode and local storage."""
from __future__ import annotations
from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QTextBlockFormat, QTextCursor
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QLabel,QComboBox,
    QPlainTextEdit,QPushButton,QCheckBox,QMessageBox,QTableWidget,QTableWidgetItem,
    QAbstractItemView,QHeaderView,QSplitter,QWidget,QMenu)
from lxml import html as LH
from bilingual_alignment import (AlignmentStore,AlignmentError,PairText,pair_entries,
    validate_groups,draft_groups,group_editor_text,parse_editor,DELIMITER)
from publisher_core import PublisherResources


class AlignmentDialog(QDialog):
    def __init__(self,store,path,pairs,parent=None):
        super().__init__(parent)
        self.store,self.path,self.pairs=store,path,[p for p in pairs if p.editable]
        self.modified=False;self.dirty=False;self._index=-1;self._loading=False
        self.setWindowTitle('句组对照校对 · 只存本机，不改动 EPUB');self.resize(1120,800)
        layout=QVBoxLayout(self)
        label=QLabel('按完整意思分组，两侧同一行须相互对应，可一对多/多对一。只插入分组符，不改正文。\n'
                     '“按标点生成草案”不理解翻译关系；请逐组检查后勾选确认。不确定的段落保留整段显示。')
        label.setWordWrap(True);layout.addWidget(label)
        self.combo=QComboBox();self.combo.setMinimumWidth(400)
        for i,p in enumerate(self.pairs): self.combo.addItem(f'{i+1}  {p.en[:100].strip()}')
        self.combo.currentIndexChanged.connect(self._choose);layout.addWidget(self.combo)
        splitter=QSplitter(Qt.Orientation.Horizontal);layout.addWidget(splitter,3)
        self.edits=[]
        for title in ('英文原段','中文原段'):
            pane=QWidget();column=QVBoxLayout(pane);column.setContentsMargins(0,0,0,0)
            column.addWidget(QLabel(title));edit=QPlainTextEdit();edit.setLineWrapMode(QPlainTextEdit.LineWrapMode.WidgetWidth)
            column.addWidget(edit,1);button=QPushButton('在光标处插入分组符')
            button.clicked.connect(lambda _=False,e=edit:e.insertPlainText(DELIMITER))
            column.addWidget(button);splitter.addWidget(pane);self.edits.append(edit)
            edit.textChanged.connect(self._edited)
        row=QHBoxLayout();layout.addLayout(row)
        for text,callback in [('按标点生成草案（未核对）',self._draft),('恢复原段',self._reset),('预览分组',self._preview)]:
            button=QPushButton(text);button.clicked.connect(callback);row.addWidget(button)
        self.preview=QTableWidget(0,2);self.preview.setHorizontalHeaderLabels(['英文组','中文组'])
        self.preview.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.preview.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers);self.preview.setWordWrap(True)
        layout.addWidget(self.preview,2)
        self.confirm=QCheckBox('我已逐组核对英文与中文含义对应（不是只检查两侧组数相同）');layout.addWidget(self.confirm)
        self.note=QLabel('');self.note.setWordWrap(True);layout.addWidget(self.note)
        row=QHBoxLayout();layout.addLayout(row)
        for text,callback in [('保存本段对齐',self._save),('清除本段对齐',self._remove),('完成',self.accept)]:
            button=QPushButton(text);button.clicked.connect(callback);row.addWidget(button)
        if self.pairs:self._load(0)
        else:self.note.setText('本章没有可安全拆分的普通双语段落。表格、公式、图片和复杂块保留原样。')

    def _current(self): return self.pairs[self._index] if 0<=self._index<len(self.pairs) else None
    def _edited(self):
        if self._loading:return
        self.dirty=True;self.confirm.setChecked(False);self.preview.setRowCount(0)
        self.note.setText('未保存。修改分组后需要重新预览并核对。')
    def _discard(self):
        return (not self.dirty or QMessageBox.question(self,'未保存的分组','放弃当前未保存的分组？',
            QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,QMessageBox.StandardButton.No)==QMessageBox.StandardButton.Yes)
    def _choose(self,index):
        if self._loading or index==self._index:return
        if not self._discard():
            self.combo.blockSignals(True);self.combo.setCurrentIndex(self._index);self.combo.blockSignals(False);return
        self._load(index)
    def _load(self,index):
        if not 0<=index<len(self.pairs):return
        self._index=index;p=self._current();record=self.store.chapter(self.path).get(p.key)
        try: ends=validate_groups(p,record)
        except AlignmentError:ends=[(len(p.en),len(p.zh))]
        self._set_text(p,ends);self.confirm.setChecked(bool(record));self.dirty=False
        self.note.setText('已有本机对齐记录。' if record else '尚未设置；原文按整段显示。')
        self._preview(silent=True)
    def _set_text(self,p,ends):
        self._loading=True
        for i,text in enumerate((p.en,p.zh)):
            self.edits[i].setPlainText(group_editor_text(text,[e[i] for e in ends]))
        self._loading=False
    def _reset(self):
        p=self._current()
        if p:self._set_text(p,[(len(p.en),len(p.zh))]);self._edited()
    def _draft(self):
        p=self._current()
        if not p:return
        try:
            ends=draft_groups(p);self._set_text(p,ends);self._edited();self._preview(silent=True)
            self.note.setText('这是标点分句草案，不是经过语义验证的对齐。请检查，不正确时删除/移动分组符。')
        except AlignmentError as exc:QMessageBox.information(self,'不能自动生成草案',str(exc))
    def _values(self):
        return parse_editor(self._current(),*(e.document().toRawText().replace('\u2029','\n') for e in self.edits))
    def _preview(self,_checked=False,silent=False):
        p=self._current()
        if not p:return
        try:ends=self._values()
        except AlignmentError as exc:
            if not silent:QMessageBox.warning(self,'分组无效',str(exc))
            return
        self.preview.setRowCount(len(ends));last=(0,0)
        for row,end in enumerate(ends):
            for col,text in enumerate((p.en,p.zh)):
                value=text[last[col]:end[col]];item=QTableWidgetItem(value);item.setToolTip(value)
                self.preview.setItem(row,col,item)
            last=end
        self.preview.resizeRowsToContents()
        for row in range(len(ends)):self.preview.setRowHeight(row,min(220,max(50,self.preview.rowHeight(row))))
        self.note.setText(f'{len(ends)} 组；两侧完整原文校验通过。请另行核对每组含义。')
    def _save(self):
        p=self._current()
        if not p:return
        if not self.confirm.isChecked():
            QMessageBox.information(self,'需要核对','请先核对每组对应关系，再勾选确认。');return
        try:
            self.store.save_pair(self.path,p,self._values())
            self.modified=True;self.dirty=False;self.note.setText('已保存到本机。关闭窗口后应用；原 EPUB 未改动。')
        except (OSError,ValueError) as exc:QMessageBox.warning(self,'未保存',str(exc))
    def _remove(self):
        p=self._current()
        if not p:return
        try:
            self.store.remove_pair(self.path,p.key);self.modified=True;self._load(self._index)
        except (OSError,ValueError) as exc:QMessageBox.warning(self,'未清除',str(exc))
    def accept(self):
        if self._discard():super().accept()
    def reject(self):
        if self._discard():super().reject()


class ParallelToolsMixin:
    def __init__(self,state):
        self.copy_language_lock=state.data['preferences'].get('copy_language_lock',True) is not False
        self.use_sentence_groups=state.data['preferences'].get('use_sentence_groups',True) is not False
        self.auto_sentence_groups=state.data['preferences'].get('auto_sentence_groups',True) is not False
        self._alignment_store=None
        super().__init__(state)

    def _build_ui(self):
        super()._build_ui()
        self.browser.copy_lock=self.copy_language_lock
        menu=self.menuBar().addMenu('双语')
        self.copy_lock_action=self._action('跨段复制锁定起选语言',self.set_copy_lock,checkable=True)
        self.copy_lock_action.setChecked(self.copy_language_lock);menu.addAction(self.copy_lock_action)
        menu.addAction(self._action('对照推荐：英文55% / 中文45%，同行距',self.balanced_columns))
        self.auto_groups_action=self._action('自动句组对齐（近似）',self.set_auto_sentence_groups,checkable=True)
        self.auto_groups_action.setChecked(self.auto_sentence_groups)
        self.auto_groups_action.setToolTip('在已有对应段落内按标点与相对长度近似分组；支持保守的一对二/二对一。不是逐行语义翻译，可随时关闭。')
        menu.addAction(self.auto_groups_action)
        self.groups_action=self._action('应用已核对句组',self.set_sentence_groups,checkable=True)
        self.groups_action.setChecked(self.use_sentence_groups);menu.addAction(self.groups_action)
        menu.addAction(self._action('句组对照校对…',self.edit_sentence_groups,'Ctrl+Alt+G'))
        menu.addSeparator()
        menu.addAction(self._action('双语复制与对齐说明',self.explain_parallel_tools))
        action=QAction('双语工具',self);action.setMenu(menu);self.layout_toolbar.addAction(action)

    def _get_alignment_store(self):
        if self.book is None:return None
        if self._alignment_store is None or self._alignment_store.book_id!=self.book.book_id:
            self._alignment_store=AlignmentStore(self.store.filename.parent,self.book.book_id)
            if self._alignment_store.warning:self.statusBar().showMessage(self._alignment_store.warning,12000)
        return self._alignment_store
    def _alignment_records(self,path):
        store=self._get_alignment_store()
        return store.chapter(path) if store else {}
    def _make_publication_resources(self):
        return PublisherResources(self.book,self._get_alignment_store(),self.use_sentence_groups,
                                  auto_groups=self.auto_sentence_groups)
    def _payload(self):
        payload=super()._payload();payload['copy_lock']=self.copy_language_lock;return payload
    def _extend_saved_state(self):
        super()._extend_saved_state()
        self.store.data['preferences']['copy_language_lock']=self.copy_language_lock
        self.store.data['preferences']['use_sentence_groups']=self.use_sentence_groups
        self.store.data['preferences']['auto_sentence_groups']=self.auto_sentence_groups
    def set_copy_lock(self,value):
        self.copy_language_lock=bool(value);self.browser.copy_lock=bool(value)
        self.browser._update_copy_highlight()
        if self._using_publication():self.publication_view.apply_settings(self._payload())
        self._save_timer.start()
    def set_sentence_groups(self,value):
        self.use_sentence_groups=bool(value)
        if self.book is not None:self.reload_chapter()
        self._save_timer.start()
    def set_auto_sentence_groups(self,value):
        self.auto_sentence_groups=bool(value)
        self.auto_groups_action.setChecked(self.auto_sentence_groups)
        if self.book is not None:self.reload_chapter()
        self._save_timer.start()
    def balanced_columns(self):
        if self.book is None or self.pdf_book is not None:return
        mode='parallel' if self._using_publication() else 'compatible'
        self.set_layout(mode=mode,english_percent=55,line_height=1.8)
        self.statusBar().showMessage('已统一行距与栏宽；可继续调整英文比例。自动句组减少长段错位，需要精确对应时可校对句组。',9000)
    def _postprocess_native_document(self,document):
        if not hasattr(self,'layout_settings'):return
        height=self.layout_settings.line_height
        if height<=0:return
        block=document.begin()
        while block.isValid():
            cursor=QTextCursor(block);fmt=block.blockFormat()
            fmt.setLineHeight(round(height*100),QTextBlockFormat.LineHeightTypes.ProportionalHeight.value)
            cursor.setBlockFormat(fmt);block=block.next()
    def edit_sentence_groups(self):
        if self.book is None or self.pdf_book is not None or not self.current_path:
            QMessageBox.information(self,'句组校对','请先打开带明确中英文配对的 EPUB 章节。');return
        try:
            resource=PublisherResources(self.book,use_groups=False)
            root=LH.fromstring(resource.chapter(self.current_path))
            pairs=[p for _,_,p in pair_entries(root)]
            dialog=AlignmentDialog(self._get_alignment_store(),self.current_path,pairs,self)
            dialog.exec()
            if dialog.modified:
                self.use_sentence_groups=True;self.groups_action.setChecked(True);self.reload_chapter();self._save_timer.start()
        except (OSError,ValueError) as exc:QMessageBox.warning(self,'句组校对未完成',str(exc))
    def explain_parallel_tools(self):
        QMessageBox.information(self,'双语复制与句组对齐',
            '从英文侧开始选择多个段落，Ctrl+C 只复制英文；中文侧同理。右键可明确复制英文、中文或原始双语选区。\n\n'
            '复制按语言结构筛选，共用且没有语言标记的图表/公式不自动算作英文。需要全部内容时选“复制双语 / 原始选区”。\n\n'
            '自动句组对齐默认开启：在已有成对段落内按句组重新顶端对齐，并保守处理一句对两句，减少长段累积错位。'
            '这是标点与长度的近似排版，不能保证每个屏幕行含义相同；差异过大、公式、图表等保留原段。\n\n'
            '55/45与同行距可作为栏宽起点。需要精确对应时用句组校对，支持一对多、多对一；已核对记录优先。'
            '所有变化只作用于显示，原 EPUB 不变。\n\n'
            '老板模式仍可右键复制或按 Ctrl+Alt+G 打开临时校对窗口。')
